package myPack.OnlineBookStore.DAO;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import myPack.OnlineBookStore.Entity.User;

import java.util.Optional;

@Repository
public interface UserDAO extends JpaRepository<User, Integer> 
{	
	// Finds a user by their userName.
	// This is useful for Role assigning.
	Optional<User> findByUserName(String username);
	
    // Finds a user by their email address.
    // This is useful for login, registration checks, or email-based queries.
    Optional<User> findByUserEmail(String email);

    // Checks if a user exists with the given email.
    // Helps to prevent duplicate registrations.
    boolean existsByUserEmail(String email);
}
