package myPack.OnlineBookStore.DAO;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import myPack.OnlineBookStore.Entity.Order;
import myPack.OnlineBookStore.Entity.OrderStatus;
import myPack.OnlineBookStore.Entity.User;

@Repository
public interface OrderDAO extends JpaRepository<Order, Integer> 
{
    // Retrieves a list of orders placed by a specific user.
	// Useful for displaying order history.
    List<Order> findByUser(User user);


    // Retrieves orders by their status. (e.g., PLACED, SHIPPED)
    // Useful for admin filters or tracking.
    List<Order> findByStatus(OrderStatus orderStatus);

	// List<Order> findByUserId(Integer userId);
	
	// Using a custom query to find orders by userId
    @Query("SELECT o FROM Order o WHERE o.user.userId = :userId")
    List<Order> findByUserId(@Param("userId") Integer userId);
}
