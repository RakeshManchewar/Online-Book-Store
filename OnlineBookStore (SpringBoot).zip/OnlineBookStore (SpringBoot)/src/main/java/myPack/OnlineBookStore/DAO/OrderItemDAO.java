package myPack.OnlineBookStore.DAO;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import myPack.OnlineBookStore.Entity.Order;
import myPack.OnlineBookStore.Entity.OrderItem;

@Repository
public interface OrderItemDAO extends JpaRepository<OrderItem, Integer> 
{
    // Retrieves all items associated with a specific order.
    // Useful for displaying order details.
    List<OrderItem> findByOrder(Order order);
}
