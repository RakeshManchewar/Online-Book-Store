package myPack.OnlineBookStore.DAO;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import myPack.OnlineBookStore.Entity.Role;

@Repository
public interface RoleDAO extends JpaRepository<Role, String> 
{
    // Method to find role by roleName (matches the @Id field)
    Optional<Role> findByRoleName(String roleName);
    
    // Check if role exists by roleName (matches the @Id field)
    boolean existsByRoleName(String roleName);
}