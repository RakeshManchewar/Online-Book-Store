package myPack.OnlineBookStore.DAO;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import myPack.OnlineBookStore.Entity.Book;

import java.util.List;
import java.util.Optional;

@Repository
public interface BookDAO extends JpaRepository<Book, Integer> 
{
    // Finds a list of books with titles containing the given keyword (case-insensitive).
    List<Book> findByBookTitleContainingIgnoreCase(String keyword);

    // Finds a list of books with authors containing the given keyword (case-insensitive).
    List<Book> findByBookAuthorContainingIgnoreCase(String author);

    // Finds all books priced less than or equal to the given amount.
    List<Book> findByPriceLessThanEqual(int price);

    // Finds books where available stock is greater than the given value.
    List<Book> findByAvailableStockGreaterThan(int minStock);
    
	Optional<Book> findByBookTitle(String bookTitle);
	List<Book> findByBookAuthor(String author);
}
