package myPack.OnlineBookStore.DAO;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import myPack.OnlineBookStore.Entity.Cart;
import myPack.OnlineBookStore.Entity.CartItem;

@Repository
public interface CartItemDAO extends JpaRepository<CartItem, Integer> 
{
    // Finds all items in a specific cart.
    List<CartItem> findByCart(Cart cart);
}
