package myPack.OnlineBookStore.DAO;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import myPack.OnlineBookStore.Entity.Cart;
import myPack.OnlineBookStore.Entity.User;

@Repository
public interface CartDAO extends JpaRepository<Cart, Integer> 
{
    // Finds the cart associated with a specific user.
    Cart findByUser(User user);
}
