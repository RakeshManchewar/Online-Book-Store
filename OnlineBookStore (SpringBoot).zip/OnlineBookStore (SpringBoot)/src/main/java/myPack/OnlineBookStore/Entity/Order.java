package myPack.OnlineBookStore.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

import java.time.LocalDate;

@Entity
@Table(name = "Orders")
public class Order 
{
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private int orderId;

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;  // Relationship with User entity

    @NotNull(message = "Order Date cannot be Null")
    private LocalDate orderDate;

    private double totalAmount;

    @Enumerated(EnumType.STRING)
    private OrderStatus status;

    // Getters and Setters
	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public LocalDate getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}

	public double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public OrderStatus getStatus() {
		return status;
	}

	public void setStatus(OrderStatus status) {
		this.status = status;
	}

	// Parameterized constructor
	public Order(int orderId, User user, @NotEmpty(message = "Order Date cannot be empty") LocalDate orderDate,
			double totalAmount, OrderStatus status) {
		super();
		this.orderId = orderId;
		this.user = user;
		this.orderDate = orderDate;
		this.totalAmount = totalAmount;
		this.status = status;
	}

	// Default constructor
	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}

	// toString method
	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", user=" + user + ", orderDate=" + orderDate + ", totalAmount="
				+ totalAmount + ", status=" + status + "]";
	}
}
