package myPack.OnlineBookStore.Entity;

public enum OrderStatus 
{
    PLACED,
    SHIPPED,
    DELIVERED,
    CANCELLED
}
