package myPack.OnlineBookStore.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Positive;

@Entity
@Table(name = "Books")
public class Book 
{
	@Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int bookId;
	
	@NotEmpty(message = "Set Book Title")
	private String bookTitle;
	
	@NotEmpty(message = "Set Book Author")
	private String bookAuthor;
	
	@Positive(message = "Set a valid price")
	private int price;
	
	@NotEmpty(message = "Enter some Description")
	private String description;
	
	private int availableStock;

	// Getters and Setters
	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public String getBookTitle() {
		return bookTitle;
	}

	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}

	public String getBookAuthor() {
		return bookAuthor;
	}

	public void setBookAuthor(String bookAuthor) {
		this.bookAuthor = bookAuthor;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getAvailableStock() {
		return availableStock;
	}

	public void setAvailableStock(int availableStock) {
		this.availableStock = availableStock;
	}

	// Parameterized constructor
	public Book(int bookId, @NotEmpty(message = "Set Book Title") String bookTitle,
			@NotEmpty(message = "Set Book Author") String bookAuthor,
			@Positive(message = "Set a valid price") int price,
			@NotEmpty(message = "Enter some Description") String description, int availableStock) {
		super();
		this.bookId = bookId;
		this.bookTitle = bookTitle;
		this.bookAuthor = bookAuthor;
		this.price = price;
		this.description = description;
		this.availableStock = availableStock;
	}

	// Default constructor
	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}

	// toString method
	@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", bookTitle=" + bookTitle + ", bookAuthor=" + bookAuthor + ", price=" + price
				+ ", description=" + description + ", availableStock=" + availableStock + "]";
	}
}
