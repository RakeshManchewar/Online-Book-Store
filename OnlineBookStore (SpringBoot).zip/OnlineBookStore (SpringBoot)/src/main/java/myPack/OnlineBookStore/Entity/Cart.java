package myPack.OnlineBookStore.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "Cart")
public class Cart 
{
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private int cartId;

    @OneToOne
    @JoinColumn(name = "user_id", nullable = false, unique = true)
    private User user;

    // Getters and Setters
	public int getCartId() {
		return cartId;
	}

	public void setCartId(int cartId) {
		this.cartId = cartId;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	// Parameterized constructor
	public Cart(int cartId, User user) {
		super();
		this.cartId = cartId;
		this.user = user;
	}

	// Default constructor
	public Cart() {
		super();
		// TODO Auto-generated constructor stub
	}

	// toString method
	@Override
	public String toString() {
		return "Cart [cartId=" + cartId + ", user=" + user + "]";
	}
}
