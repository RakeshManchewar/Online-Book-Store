package myPack.OnlineBookStore.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Positive;

@Entity
@Table(name = "Cart_Items")
public class CartItem 
{
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private int cartItemId;

    @ManyToOne
    @JoinColumn(name = "cart_id", nullable = false)
    private Cart cart;

    @ManyToOne
    @JoinColumn(name = "book_id", nullable = false)
    private Book book;

    @Positive(message = "Quantity must be a positive number")
    private int quantity;

    // Getters and Setters
	public int getCartItemId() {
		return cartItemId;
	}

	public void setCartItemId(int cartItemId) {
		this.cartItemId = cartItemId;
	}

	public Cart getCart() {
		return cart;
	}

	public void setCart(Cart cart) {
		this.cart = cart;
	}

	public Book getBook() {
		return book;
	}

	public void setBook(Book book) {
		this.book = book;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	// Parameterized constructor
	public CartItem(int cartItemId, Cart cart, Book book,
			@Positive(message = "Quantity must be a positive number") int quantity) {
		super();
		this.cartItemId = cartItemId;
		this.cart = cart;
		this.book = book;
		this.quantity = quantity;
	}

	// Default constructor
	public CartItem() {
		super();
		// TODO Auto-generated constructor stub
	}

	// toString method
	@Override
	public String toString() {
		return "CartItem [cartItemId=" + cartItemId + ", cart=" + cart + ", book=" + book + ", quantity=" + quantity
				+ "]";
	}
}
