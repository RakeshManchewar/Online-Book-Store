package myPack.OnlineBookStore.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Positive;

@Entity
@Table(name = "Order_Items")
public class OrderItem 
{
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private int itemId;

    @ManyToOne
    @JoinColumn(name = "order_id", nullable = false)
    private Order order;

    @ManyToOne
    @JoinColumn(name = "book_id", nullable = false)
    private Book book;  // Direct reference to Book entity

    @Positive(message = "Quantity must be a positive number")
    private int quantity;

    @Positive(message = "Price must be a positive number")
    private double price;

    // Getters and Setters
	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public Book getBook() {
		return book;
	}

	public void setBook(Book book) {
		this.book = book;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	// Parameterized constructor
	public OrderItem(int itemId, Order order, Book book,
			@Positive(message = "Quantity must be a positive number") int quantity,
			@Positive(message = "Price must be a positive number") double price) {
		super();
		this.itemId = itemId;
		this.order = order;
		this.book = book;
		this.quantity = quantity;
		this.price = price;
	}

	// Default constructor
	public OrderItem() {
		super();
		// TODO Auto-generated constructor stub
	}

	// toString method
	@Override
	public String toString() {
		return "OrderItem [itemId=" + itemId + ", order=" + order + ", book=" + book + ", quantity=" + quantity
				+ ", price=" + price + "]";
	}
}
