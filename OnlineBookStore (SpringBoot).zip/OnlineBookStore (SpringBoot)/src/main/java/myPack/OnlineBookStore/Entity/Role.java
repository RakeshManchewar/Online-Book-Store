package myPack.OnlineBookStore.Entity;

import java.util.Set;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Role 
{
    @Id
    private String roleName;
    private String roleDescription;
    
    // Bidirectional mapping - this creates the inverse relationship
    @ManyToMany(mappedBy = "role")
    @JsonIgnore  // Prevents infinite recursion during JSON serialization
    private Set<User> users;
    
    // Getters and Setters for existing fields
    public String getRoleName() {
        return roleName;
    }
    
    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }
    
    public String getRoleDescription() {
        return roleDescription;
    }
    
    public void setRoleDescription(String roleDescription) {
        this.roleDescription = roleDescription;
    }
    
    // Getter and Setter for the new users field
    public Set<User> getUsers() {
        return users;
    }
    
    public void setUsers(Set<User> users) {
        this.users = users;
    }
    
    // Default constructor
    public Role() {
    }
    
    // Parameterized constructor
    public Role(String roleName, String roleDescription) {
        this.roleName = roleName;
        this.roleDescription = roleDescription;
    }
    
    @Override
    public String toString() {
        return "Role [roleName=" + roleName + ", roleDescription=" + roleDescription + "]";
    }
}