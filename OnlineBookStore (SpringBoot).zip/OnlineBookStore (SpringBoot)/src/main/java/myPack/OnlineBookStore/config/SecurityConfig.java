package myPack.OnlineBookStore.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity(prePostEnabled = true)
public class SecurityConfig 
{
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
    
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable())
            .authorizeHttpRequests(authz -> authz
                // Public endpoints
                .requestMatchers(
                    "/api/users/login", 
                    "/api/users/register", 
                    "/api/users/get/all", 
                    "/api/users/registerNewUser",
                    "/api/books/**",
                    "/api/carts/**",
                    "/api/cart-items/**",
                    "/api/payment/**",
                    "/api/orders/**",
                    "/api/order-items/**"
                ).permitAll()
                
                // Admin-only endpoints
                .requestMatchers(
                    "/api/users/forAdmin", 
                    "/api/users/getAllUserDetails", 
                    "/api/users/by-role/**", 
                    "/api/users/admins", 
                    "/api/users/regular-users",
                    "/api/users/*/add-role/**",
                    "/api/users/*/remove-role/**",
                    "/api/users/*/has-role/**",
                    "/api/users/{id:[0-9]+}/delete"
                ).hasRole("ADMIN")
                
                // User and Admin endpoints
                .requestMatchers(
                    "/api/users/forUser", 
                    "/api/users/email", 
                    "/api/users/{id:[0-9]+}"
                ).hasAnyRole("USER", "ADMIN")
                
                // Role management endpoints
                .requestMatchers("/api/roles/**").hasRole("ADMIN")
                
                // All other requests need authentication
                .anyRequest().authenticated()
            )
            .httpBasic(httpBasic -> httpBasic.disable())
            .formLogin(form -> form.disable());
        
        return http.build();
    }
}