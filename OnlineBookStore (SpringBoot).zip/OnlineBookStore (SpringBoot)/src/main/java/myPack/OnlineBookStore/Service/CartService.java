package myPack.OnlineBookStore.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import myPack.OnlineBookStore.DAO.CartDAO;
import myPack.OnlineBookStore.DAO.UserDAO;
import myPack.OnlineBookStore.Entity.Cart;
import myPack.OnlineBookStore.Entity.User;
import java.util.List;

@Service
public class CartService {
    
    @Autowired
    private CartDAO cartDAO;
    
    @Autowired
    private UserDAO userDAO;
    
    // Create a new cart for a user
    @Transactional
    public Cart createCart(int userId) {
        User user = userDAO.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found with ID: " + userId));
        
        // Check if cart already exists
        Cart existingCart = cartDAO.findByUser(user);
        if (existingCart != null) {
            System.out.println("Cart already exists for user ID: " + userId + ", returning existing cart");
            return existingCart;
        }
        
        System.out.println("Creating new cart for user ID: " + userId);
        Cart cart = new Cart();
        cart.setUser(user);
        return cartDAO.save(cart);
    }
    
    @Transactional
    public Cart getOrCreateCart(int userId) {
        System.out.println("Getting or creating cart for user ID: " + userId);
        
        User user = userDAO.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found with ID: " + userId));
        
        Cart cart = cartDAO.findByUser(user);
        
        if (cart == null) {
            System.out.println("No existing cart found, creating new cart for user: " + userId);
            cart = new Cart();
            cart.setUser(user);
            cart = cartDAO.save(cart);
            System.out.println("Created new cart with ID: " + cart.getCartId() + " for user: " + userId);
        } else {
            System.out.println("Found existing cart with ID: " + cart.getCartId() + " for user: " + userId);
        }
        
        return cart;
    }
    
    // Retrieve a cart by its ID
    public Cart getCartById(int cartId) {
        return cartDAO.findById(cartId)
                .orElseThrow(() -> new RuntimeException("Cart not found with ID: " + cartId));
    }
    
    // Retrieve a cart by user ID - This method was missing!
    @Transactional
    public Cart getCartByUserId(int userId) {
        System.out.println("Getting cart by user ID: " + userId);
        
        User user = userDAO.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found with ID: " + userId));

        Cart cart = cartDAO.findByUser(user);
        if (cart == null) {
            throw new RuntimeException("Cart not found for user ID: " + userId);
        }
        
        System.out.println("Found cart with ID: " + cart.getCartId() + " for user: " + userId);
        return cart;
    }
    
    // Get all carts
    public List<Cart> getAllCarts() {
        return cartDAO.findAll();
    }
    
    // Delete a cart
    @Transactional
    public void deleteCart(int cartId) {
        if (!cartDAO.existsById(cartId)) {
            throw new RuntimeException("Cart not found with ID: " + cartId);
        }
        cartDAO.deleteById(cartId);
    }
}
