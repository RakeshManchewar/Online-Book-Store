package myPack.OnlineBookStore.Service;

import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;
import myPack.OnlineBookStore.DTO.PaymentRequest;
import myPack.OnlineBookStore.DTO.PaymentResponse;
import myPack.OnlineBookStore.DTO.PaymentVerification;
import myPack.OnlineBookStore.Utilities.RazorpayUtils;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class PaymentService {
    @Value("${razorpay.key_id}")
    private String razorpayKeyId;

    @Value("${razorpay.key_secret}")
    private String razorpayKeySecret;

    public PaymentResponse createOrder(PaymentRequest paymentRequest) throws RazorpayException {
        RazorpayClient razorpayClient = new RazorpayClient(razorpayKeyId, razorpayKeySecret);

        JSONObject orderRequest = new JSONObject();
        orderRequest.put("amount", paymentRequest.getAmount() * 100); // amount in paise
        orderRequest.put("currency", paymentRequest.getCurrency());
        orderRequest.put("receipt", paymentRequest.getReceipt());
        orderRequest.put("payment_capture", 1); // auto capture payment

        Order order = razorpayClient.orders.create(orderRequest);

        PaymentResponse paymentResponse = new PaymentResponse();
        paymentResponse.setOrderId(order.get("id"));
        paymentResponse.setCurrency(order.get("currency"));
        paymentResponse.setAmount((Integer)order.get("amount") / 100.0); // convert back to rupees
        paymentResponse.setKey(razorpayKeyId);
        paymentResponse.setStatus("created");

        return paymentResponse;
    }

    public boolean verifyPayment(PaymentVerification paymentVerification) throws RazorpayException {
        RazorpayClient razorpayClient = new RazorpayClient(razorpayKeyId, razorpayKeySecret);
        
        String generatedSignature = RazorpayUtils.generateSignature(
            paymentVerification.getRazorpayOrderId() + "|" + paymentVerification.getRazorpayPaymentId(),
            razorpayKeySecret
        );

        return generatedSignature.equals(paymentVerification.getRazorpaySignature());
    }
}