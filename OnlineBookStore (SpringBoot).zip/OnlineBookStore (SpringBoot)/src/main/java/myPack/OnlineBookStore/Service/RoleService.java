package myPack.OnlineBookStore.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import myPack.OnlineBookStore.DAO.RoleDAO;
import myPack.OnlineBookStore.Entity.Role;
import myPack.OnlineBookStore.Entity.User;

@Service
public class RoleService 
{
    @Autowired
    private RoleDAO roleDAO;
    
    public Role createNewRole(Role role) {
        return roleDAO.save(role);
    }
    
    public List<Role> getAllRoles() {
        return roleDAO.findAll();
    }
    
    public Role getRoleByName(String roleName) {
        return roleDAO.findByRoleName(roleName)
            .orElseThrow(() -> new RuntimeException("Role not found: " + roleName));
    }
    
    // Updated to use existsByRoleName
    public boolean roleExists(String roleName) {
        return roleDAO.existsByRoleName(roleName);
    }
    
    public int getUserCountForRole(String roleName) {
        Role role = getRoleByName(roleName);
        return role.getUsers() != null ? role.getUsers().size() : 0;
    }
    
    public List<User> getUsersForRole(String roleName) {
        Role role = getRoleByName(roleName);
        return role.getUsers() != null ? new ArrayList<>(role.getUsers()) : new ArrayList<>();
    }
    
    public void deleteRole(String roleName) {
        Role role = getRoleByName(roleName);
        
        if (role.getUsers() != null && !role.getUsers().isEmpty()) {
            throw new RuntimeException("Cannot delete role '" + roleName + "'. It has " + 
                                     role.getUsers().size() + " users assigned.");
        }
        
        roleDAO.deleteById(roleName);
    }
    
    public Role updateRoleDescription(String roleName, String newDescription) {
        Role role = getRoleByName(roleName);
        role.setRoleDescription(newDescription);
        return roleDAO.save(role);
    }
}
