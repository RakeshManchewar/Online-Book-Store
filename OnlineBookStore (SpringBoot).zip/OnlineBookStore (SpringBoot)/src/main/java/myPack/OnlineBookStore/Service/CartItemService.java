package myPack.OnlineBookStore.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import myPack.OnlineBookStore.DAO.BookDAO;
import myPack.OnlineBookStore.DAO.CartDAO;
import myPack.OnlineBookStore.DAO.CartItemDAO;
import myPack.OnlineBookStore.Entity.Book;
import myPack.OnlineBookStore.Entity.Cart;
import myPack.OnlineBookStore.Entity.CartItem;

@Service
public class CartItemService 
{
    @Autowired
    private CartItemDAO cartItemDAO;

    @Autowired
    private CartDAO cartDAO;

    @Autowired
    private BookDAO bookDAO;

    // Add item to cart
    public CartItem addCartItem(int cartId, int bookId, int quantity) {
        Cart cart = cartDAO.findById(cartId)
                .orElseThrow(() -> new RuntimeException("Cart not found with ID: " + cartId));
        Book book = bookDAO.findById(bookId)
                .orElseThrow(() -> new RuntimeException("Book not found with ID: " + bookId));

        CartItem cartItem = new CartItem();
        cartItem.setCart(cart);
        cartItem.setBook(book);
        cartItem.setQuantity(quantity);

        return cartItemDAO.save(cartItem);
    }

    // Get cart item by ID
    public CartItem getCartItemById(int cartItemId) {
        return cartItemDAO.findById(cartItemId)
                .orElseThrow(() -> new RuntimeException("CartItem not found with ID: " + cartItemId));
    }

    // Get all items in a cart
    public List<CartItem> getItemsByCartId(int cartId) {
        Cart cart = cartDAO.findById(cartId)
                .orElseThrow(() -> new RuntimeException("Cart not found with ID: " + cartId));

        return cartItemDAO.findByCart(cart);
    }

    // Update cart item quantity
    public CartItem updateCartItemQuantity(int cartItemId, int quantity) {
        CartItem cartItem = cartItemDAO.findById(cartItemId)
                .orElseThrow(() -> new RuntimeException("CartItem not found with ID: " + cartItemId));

        cartItem.setQuantity(quantity);
        return cartItemDAO.save(cartItem);
    }

    // Delete cart item
    public void deleteCartItem(int cartItemId) {
        if (!cartItemDAO.existsById(cartItemId)) {
            throw new RuntimeException("CartItem not found with ID: " + cartItemId);
        }
        cartItemDAO.deleteById(cartItemId);
    }

    // Delete all items from a cart
    public void deleteItemsByCartId(int cartId) {
        Cart cart = cartDAO.findById(cartId)
                .orElseThrow(() -> new RuntimeException("Cart not found with ID: " + cartId));

        List<CartItem> items = cartItemDAO.findByCart(cart);
        cartItemDAO.deleteAll(items);
    }
}
