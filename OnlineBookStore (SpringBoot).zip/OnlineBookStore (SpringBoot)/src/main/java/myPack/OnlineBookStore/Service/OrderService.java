package myPack.OnlineBookStore.Service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import myPack.OnlineBookStore.DAO.OrderDAO;
import myPack.OnlineBookStore.DAO.UserDAO;
import myPack.OnlineBookStore.Entity.Order;
import myPack.OnlineBookStore.Entity.OrderStatus;
import myPack.OnlineBookStore.Entity.User;

@Service
public class OrderService 
{
    @Autowired
    private OrderDAO orderDAO;

    @Autowired
    private UserDAO userDAO;

    // Create new order
    public Order placeOrder(int userId, double totalAmount) {
        User user = userDAO.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found with ID: " + userId));

        Order order = new Order();
        order.setUser(user);
        order.setOrderDate(LocalDate.now());
        order.setTotalAmount(totalAmount);
        order.setStatus(OrderStatus.PLACED);

        return orderDAO.save(order);
    }

    // Get all orders
    public List<Order> getAllOrders() {
        return orderDAO.findAll();
    }

    // Get order by ID
    public Order getOrderById(int orderId) {
        return orderDAO.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found with ID: " + orderId));
    }

    // Get orders by user ID
    public List<Order> getOrdersByUserId(int userId) {
        return orderDAO.findByUserId(userId);
    }

    // Get orders by status
    public List<Order> getOrdersByStatus(String status) {
        return orderDAO.findByStatus(OrderStatus.valueOf(status.toUpperCase()));
    }

    // Update order status
    public Order updateOrderStatus(int orderId, OrderStatus status) {
        Order order = getOrderById(orderId);
        order.setStatus(status);
        return orderDAO.save(order);
    }

    // Delete order
    public void deleteOrder(int orderId) {
        if (!orderDAO.existsById(orderId)) {
            throw new RuntimeException("Order not found with ID: " + orderId);
        }
        orderDAO.deleteById(orderId);
    }
}
