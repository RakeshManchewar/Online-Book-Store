package myPack.OnlineBookStore.Service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import myPack.OnlineBookStore.DAO.RoleDAO;
import myPack.OnlineBookStore.DAO.UserDAO;
import myPack.OnlineBookStore.Entity.Role;
import myPack.OnlineBookStore.Entity.User;

@Service
public class UserService 
{
    @Autowired
    private UserDAO userDAO;
    
    @Autowired
    private RoleDAO roleDAO;
    
    @Autowired
    private PasswordEncoder passwordEncoder;
    
    @Transactional
    public void initRoleAndUser() {
        try {
            // Admin role
            if (!roleDAO.existsById("Admin")) {
                Role adminRole = new Role();
                adminRole.setRoleName("Admin");
                adminRole.setRoleDescription("Admin role");
                roleDAO.save(adminRole);
            }
            
            // User role
            if (!roleDAO.existsById("User")) {
                Role userRole = new Role();
                userRole.setRoleName("User");
                userRole.setRoleDescription("User role");
                roleDAO.save(userRole);
            }

            // Admin user
            if (!userDAO.existsByUserEmail("admin@gmail.com")) {
                User adminUser = new User();
                adminUser.setUserEmail("admin@gmail.com");
                adminUser.setUserPassword(getEncodedPassword("Admin@123"));
                adminUser.setUserName("admin");
                
                Role adminRole = roleDAO.findById("Admin").get();
                Set<Role> adminRoles = new HashSet<>();
                adminRoles.add(adminRole);
                adminUser.setRole(adminRoles);
                
                userDAO.save(adminUser);
            }
        } catch (DataIntegrityViolationException e) {
            // Log and continue - data already exists
            System.err.println("Initial data already exists: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("Error initializing data: " + e.getMessage());
            throw e;
        }
    }
    
    public User registerNewUser(User user) {
        Role role = roleDAO.findById("User").get();
        Set<Role> userRoles = new HashSet<>();
        userRoles.add(role);
        user.setRole(userRoles);
        user.setUserPassword(getEncodedPassword(user.getUserPassword()));
        return userDAO.save(user);
    }

    public String getEncodedPassword(String password) {
        return passwordEncoder.encode(password);
    }

    public List<User> getAllUserDetails() {
        return userDAO.findAll();
    }
    
    // Get users by role name
    public List<User> getUsersByRole(String roleName) {
        Role role = roleDAO.findById(roleName)
            .orElseThrow(() -> new RuntimeException("Role not found: " + roleName));
        return new ArrayList<>(role.getUsers());
    }
    
    // Get all admin users
    public List<User> getAllAdminUsers() {
        return getUsersByRole("Admin");
    }
    
    // Get all regular users
    public List<User> getAllRegularUsers() {
        return getUsersByRole("User");
    }
    
    // Check if user has specific role
    public boolean userHasRole(Integer userId, String roleName) {
        User user = getUserById(userId);
        return user.getRole().stream()
            .anyMatch(role -> role.getRoleName().equals(roleName));
    }
    
    // Add role to existing user
    public User addRoleToUser(Integer userId, String roleName) {
        User user = getUserById(userId);
        Role role = roleDAO.findById(roleName)
            .orElseThrow(() -> new RuntimeException("Role not found: " + roleName));
        
        user.getRole().add(role);
        return userDAO.save(user);
    }
    
    // Remove role from user
    public User removeRoleFromUser(Integer userId, String roleName) {
        User user = getUserById(userId);
        user.getRole().removeIf(role -> role.getRoleName().equals(roleName));
        return userDAO.save(user);
    }
    
    // Register a new user with proper password encoding
    public User registerUser(User user) {
        if (userDAO.existsByUserEmail(user.getUserEmail())) {
            throw new RuntimeException("Email already exists: " + user.getUserEmail());
        }
        
        // Encode password and assign default role
        user.setUserPassword(getEncodedPassword(user.getUserPassword()));
        
        // Assign default "User" role
        Role userRole = roleDAO.findById("User")
            .orElseThrow(() -> new RuntimeException("Default User role not found"));
        Set<Role> roles = new HashSet<>();
        roles.add(userRole);
        user.setRole(roles);
        
        return userDAO.save(user);
    }

    // Authenticate user login with password encoding
    public String loginUser(String email, String password) {
        Optional<User> userOpt = userDAO.findByUserEmail(email);
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            // ✅ Use password encoder to match encrypted password
            if (passwordEncoder.matches(password, user.getUserPassword())) {
                return "Welcome " + user.getUserName();
            } else {
                return "Invalid password";
            }
        } else {
            return "User not found with email: " + email;
        }
    }

    // Retrieve all users
    public List<User> getAllUsers() {
        return userDAO.findAll();
    }

    // Get a user by ID
    public User getUserById(Integer userId) {
        return userDAO.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found with ID: " + userId));
    }

    // Update existing user details with password handling
    public User updateUser(User user) {
        User existingUser = userDAO.findById(user.getUserId())
                .orElseThrow(() -> new RuntimeException("User not found with ID: " + user.getUserId()));
        
        // If password is being updated, encode it
        if (user.getUserPassword() != null && !user.getUserPassword().isEmpty()) {
            user.setUserPassword(getEncodedPassword(user.getUserPassword()));
        } else {
            // Keep existing password if not updating
            user.setUserPassword(existingUser.getUserPassword());
        }
        
        // Keep existing roles if not specified
        if (user.getRole() == null || user.getRole().isEmpty()) {
            user.setRole(existingUser.getRole());
        }
        
        return userDAO.save(user);
    }

    // Delete a user by ID
    public void deleteUser(Integer userId) {
        if (!userDAO.existsById(userId)) {
            throw new RuntimeException("Cannot delete. User not found with ID: " + userId);
        }
        userDAO.deleteById(userId);
    }

    // Get user by email
    public User getUserByEmail(String email) {
        return userDAO.findByUserEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found with email: " + email));
    }
    
    public User authenticateUser(String email, String password) {
        try {
            Optional<User> userOptional = userDAO.findByUserEmail(email);
            if (userOptional.isPresent()) {
                User user = userOptional.get();
                // Check if password matches (assuming you have password encoding)
                if (passwordEncoder.matches(password, user.getUserPassword())) {
                    return user;
                }
            }
            return null;
        } catch (Exception e) {
            throw new RuntimeException("Authentication failed: " + e.getMessage());
        }
    }
}