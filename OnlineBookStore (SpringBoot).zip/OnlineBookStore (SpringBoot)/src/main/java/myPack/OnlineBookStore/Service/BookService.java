package myPack.OnlineBookStore.Service;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import myPack.OnlineBookStore.DAO.BookDAO;
import myPack.OnlineBookStore.Entity.Book;

@Service
public class BookService 
{
    @Autowired
    private BookDAO bookDAO;

    // Retrieve all books
    public List<Book> getAllBooks() {
        List<Book> books = new ArrayList<>();
        bookDAO.findAll().forEach(books::add);
        return books;
    }

    // Fetch single book by ID
    public Book getBookById(Integer bookId) {
        return bookDAO.findById(bookId).orElseThrow(() -> 
            new RuntimeException("Book not found with ID: " + bookId));
    }

    // Insert new book
    public Book saveBook(Book book) {
        return bookDAO.save(book);
    }

    // Update existing book
    public Book updateBook(Book book) {
        bookDAO.findById(book.getBookId()).orElseThrow(() ->
            new RuntimeException("Book not found with ID: " + book.getBookId()));
        return bookDAO.save(book);
    }

    // Delete a book
    public void deleteBook(Integer bookId) {
        bookDAO.deleteById(bookId);
    }

    // Search book by title
    public Book getBookByTitle(String bookTitle) {
        return bookDAO.findByBookTitle(bookTitle)
            .orElseThrow(() -> new RuntimeException("Book not found with title: " + bookTitle));
    }

    // Get all books sorted by title
    public List<Book> getBooksSortedByTitle() {
        return bookDAO.findAll(Sort.by(Sort.Direction.ASC, "bookTitle"));
    }

    // Search books by author
    public List<Book> getBooksByAuthor(String author) {
        return bookDAO.findByBookAuthor(author);
    }
}
