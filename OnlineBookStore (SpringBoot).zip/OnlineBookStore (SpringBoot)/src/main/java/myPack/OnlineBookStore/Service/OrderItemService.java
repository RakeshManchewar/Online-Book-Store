package myPack.OnlineBookStore.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import myPack.OnlineBookStore.DAO.BookDAO;
import myPack.OnlineBookStore.DAO.OrderDAO;
import myPack.OnlineBookStore.DAO.OrderItemDAO;
import myPack.OnlineBookStore.Entity.Book;
import myPack.OnlineBookStore.Entity.Order;
import myPack.OnlineBookStore.Entity.OrderItem;

@Service
public class OrderItemService 
{
    @Autowired
    private OrderItemDAO orderItemDAO;

    @Autowired
    private OrderDAO orderDAO;

    @Autowired
    private BookDAO bookDAO;

    // Add order item
    public OrderItem addOrderItem(int orderId, int bookId, int quantity, double price) {
        Order order = orderDAO.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found with ID: " + orderId));
        Book book = bookDAO.findById(bookId)
                .orElseThrow(() -> new RuntimeException("Book not found with ID: " + bookId));

        OrderItem item = new OrderItem();
        item.setOrder(order);
        item.setBook(book);
        item.setQuantity(quantity);
        item.setPrice(price);

        return orderItemDAO.save(item);
    }

    // Get all order items
    public List<OrderItem> getAllOrderItems() {
        return orderItemDAO.findAll();
    }

    // Get items by order ID
    public List<OrderItem> getItemsByOrderId(int orderId) {
        Order order = orderDAO.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found with ID: " + orderId));
        return orderItemDAO.findByOrder(order);
    }

    // Get item by item ID
    public OrderItem getOrderItemById(int itemId) {
        return orderItemDAO.findById(itemId)
                .orElseThrow(() -> new RuntimeException("Order item not found with ID: " + itemId));
    }

    // Delete an order item
    public void deleteOrderItem(int itemId) {
        if (!orderItemDAO.existsById(itemId)) {
            throw new RuntimeException("Order item not found with ID: " + itemId);
        }
        orderItemDAO.deleteById(itemId);
    }
}
