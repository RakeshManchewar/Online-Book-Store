package myPack.OnlineBookStore.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import myPack.OnlineBookStore.DTO.AddItem;
import myPack.OnlineBookStore.Entity.OrderItem;
import myPack.OnlineBookStore.Service.OrderItemService;

@RestController
@CrossOrigin("http://localhost:4200")
@RequestMapping("/api/order-items")
public class OrderItemController 
{
    @Autowired
    private OrderItemService orderItemService;

    // Add order item
    @PostMapping("/add")
    public ResponseEntity<OrderItem> addOrderItem(@RequestBody AddItem request) {
        return ResponseEntity.ok(orderItemService.addOrderItem(request.getOrderId(), request.getBookId(), request.getQuantity(), request.getPrice()));
    }

    // Get all order items
    @GetMapping
    public ResponseEntity<List<OrderItem>> getAllOrderItems() {
        return ResponseEntity.ok(orderItemService.getAllOrderItems());
    }

    // Get items by order ID
    @GetMapping("/order/{orderId}")
    public ResponseEntity<List<OrderItem>> getItemsByOrderId(@PathVariable int orderId) {
        return ResponseEntity.ok(orderItemService.getItemsByOrderId(orderId));
    }

    // Get order item by item ID
    @GetMapping("/{itemId}")
    public ResponseEntity<OrderItem> getOrderItemById(@PathVariable int itemId) {
        return ResponseEntity.ok(orderItemService.getOrderItemById(itemId));
    }

    // Delete order item
    @DeleteMapping("/{itemId}")
    public ResponseEntity<String> deleteOrderItem(@PathVariable int itemId) {
        orderItemService.deleteOrderItem(itemId);
        return ResponseEntity.ok("Deleted order item with ID: " + itemId);
    }
}
