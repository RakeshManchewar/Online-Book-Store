package myPack.OnlineBookStore.Controller;

import myPack.OnlineBookStore.DTO.PaymentRequest;
import myPack.OnlineBookStore.DTO.PaymentResponse;
import myPack.OnlineBookStore.DTO.PaymentVerification;
import myPack.OnlineBookStore.Service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin("http://localhost:4200")
@RestController
@RequestMapping("/api/payment")
public class PaymentController 
{
    @Autowired
    private PaymentService paymentService;

    @PostMapping("/create-order")
    public ResponseEntity<PaymentResponse> createOrder(@RequestBody PaymentRequest paymentRequest) 
    {
        try 
        {
            PaymentResponse paymentResponse = paymentService.createOrder(paymentRequest);
            return ResponseEntity.ok(paymentResponse);
        } 
        catch (Exception e) 
        {
            e.printStackTrace();
            return ResponseEntity.badRequest().build();
        }
    }

    @PostMapping("/verify")
    public ResponseEntity<String> verifyPayment(@RequestBody PaymentVerification paymentVerification) 
    {
        try 
        {
            boolean isValid = paymentService.verifyPayment(paymentVerification);
            if (isValid) 
            {
                // Here you can update your order status in database
                return ResponseEntity.ok("Payment verified successfully");
            } 
            else 
            {
                return ResponseEntity.badRequest().body("Payment verification failed");
            }
        } 
        catch (Exception e) 
        {
            e.printStackTrace();
            return ResponseEntity.internalServerError().body("Error verifying payment");
        }
    }
}
