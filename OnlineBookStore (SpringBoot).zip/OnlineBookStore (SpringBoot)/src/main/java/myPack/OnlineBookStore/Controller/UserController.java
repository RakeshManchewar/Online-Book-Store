package myPack.OnlineBookStore.Controller;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.annotation.PostConstruct;
import myPack.OnlineBookStore.DAO.UserDAO;
import myPack.OnlineBookStore.DTO.LoginRequest;
import myPack.OnlineBookStore.DTO.LoginResponse;
import myPack.OnlineBookStore.Entity.User;
import myPack.OnlineBookStore.Service.CartService;
import myPack.OnlineBookStore.Service.UserService;

@RestController
@CrossOrigin("http://localhost:4200")
@RequestMapping("/api/users")
public class UserController 
{
    @Autowired
    private UserService userService;
    
    @Autowired
    private UserDAO userDAO;
    
    @Autowired
    private CartService cartService;
    
    @PostConstruct
    private void initRoleAndUser() {
        userService.initRoleAndUser();
    }
    
    @PostMapping("/registerNewUser")
    public ResponseEntity<?> registerNewUser(@RequestBody User user) {
        try {
            Optional<User> existingUser = userDAO.findByUserName(user.getUserName());
            if (existingUser.isPresent()) {
                return ResponseEntity.badRequest().body("Username already exists");
            }
            
            if (userDAO.existsByUserEmail(user.getUserEmail())) {
                return ResponseEntity.badRequest().body("Email already exists");
            }
            
            User registeredUser = userService.registerNewUser(user);
            cartService.createCart(registeredUser.getUserId());
            
            return ResponseEntity.ok(registeredUser);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Registration failed: " + e.getMessage());
        }
    }
    
    @GetMapping("/forAdmin")
    public String forAdmin() {
        return "This URL is only accessible to the admin";
    }
    
    @GetMapping("/forUser")
    public String forUser() {
        return "This URL is only accessible to the user";
    }
    
    @GetMapping("/getAllUserDetails")
    public List<User> getAllUserDetails() {
        return userService.getAllUserDetails();
    }
    
    @GetMapping("/by-role/{roleName}")
    public ResponseEntity<List<User>> getUsersByRole(@PathVariable String roleName) {
        return ResponseEntity.ok(userService.getUsersByRole(roleName));
    }
    
    @GetMapping("/admins")
    public ResponseEntity<List<User>> getAllAdminUsers() {
        return ResponseEntity.ok(userService.getAllAdminUsers());
    }
    
    @GetMapping("/regular-users")
    public ResponseEntity<List<User>> getAllRegularUsers() {
        return ResponseEntity.ok(userService.getAllRegularUsers());
    }
    
    @GetMapping("/{userId}/has-role/{roleName}")
    public ResponseEntity<Boolean> userHasRole(@PathVariable Integer userId, @PathVariable String roleName) {
        return ResponseEntity.ok(userService.userHasRole(userId, roleName));
    }
    
    @PostMapping("/{userId}/add-role/{roleName}")
    public ResponseEntity<User> addRoleToUser(@PathVariable Integer userId, @PathVariable String roleName) {
        return ResponseEntity.ok(userService.addRoleToUser(userId, roleName));
    }
    
    @DeleteMapping("/{userId}/remove-role/{roleName}")
    public ResponseEntity<User> removeRoleFromUser(@PathVariable Integer userId, @PathVariable String roleName) {
        return ResponseEntity.ok(userService.removeRoleFromUser(userId, roleName));
    }
    
    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@RequestBody User user) {
        try {
            if (userDAO.existsByUserEmail(user.getUserEmail())) {
                return ResponseEntity.badRequest().body("Email already exists: " + user.getUserEmail());
            }
            User registeredUser = userService.registerUser(user);
            cartService.createCart(registeredUser.getUserId());
            
            return ResponseEntity.ok(registeredUser);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Registration failed: " + e.getMessage());
        }
    }
    
    // FIXED LOGIN ENDPOINT - This was the main issue!
    @PostMapping("/login")
    public ResponseEntity<?> loginUser(@RequestBody LoginRequest loginRequest) {
        try {
            // Get the actual user from database
            User user = userService.authenticateUser(loginRequest.getUserEmail(), loginRequest.getUserPassword());
            
            if (user != null) {
                // Generate a simple token (you can use JWT here if needed)
                String token = "user_token_" + user.getUserId() + "_" + System.currentTimeMillis();
                
                // Create login response with userId and token
                LoginResponse response = new LoginResponse();
                response.setToken(token);
                response.setUserId(user.getUserId());
                response.setMessage("Welcome " + user.getUserName());
                response.setStatus("success");
                response.setUserEmail(user.getUserEmail());
                response.setUserName(user.getUserName());
                
                return ResponseEntity.ok(response);
            } else {
                return ResponseEntity.badRequest()
                    .body(new LoginResponse(null, null, "Invalid email or password", "error", null, null));
            }
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                .body(new LoginResponse(null, null, "Login failed: " + e.getMessage(), "error", null, null));
        }
    }
    
    @GetMapping("/get/all")
    public ResponseEntity<List<User>> getAllUsers() {
        return ResponseEntity.ok(userService.getAllUsers());
    }
    
    @GetMapping("/{id:[0-9]+}")
    public ResponseEntity<User> getUserById(@PathVariable Integer id) {
        return ResponseEntity.ok(userService.getUserById(id));
    }
    
    @GetMapping("/email")
    public ResponseEntity<User> getUserByEmail(@RequestParam String email) {
        return ResponseEntity.ok(userService.getUserByEmail(email));
    }
    
    @PutMapping("/{id:[0-9]+}")
    public ResponseEntity<User> updateUser(@PathVariable Integer id, @RequestBody User user) {
        user.setUserId(id);
        return ResponseEntity.ok(userService.updateUser(user));
    }
    
    @DeleteMapping("/{id:[0-9]+}")
    public ResponseEntity<String> deleteUser(@PathVariable Integer id) {
        userService.deleteUser(id);
        return ResponseEntity.ok("User deleted with ID: " + id);
    }
}
