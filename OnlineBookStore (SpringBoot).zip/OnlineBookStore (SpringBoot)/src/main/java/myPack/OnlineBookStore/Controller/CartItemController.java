package myPack.OnlineBookStore.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import myPack.OnlineBookStore.DTO.AddCartItemRequest;
import myPack.OnlineBookStore.DTO.UpdateQuantity;
import myPack.OnlineBookStore.Entity.CartItem;
import myPack.OnlineBookStore.Service.CartItemService;

@RestController
@CrossOrigin("http://localhost:4200")
@RequestMapping("/api/cart-items")
public class CartItemController 
{
    @Autowired
    private CartItemService cartItemService;
    
    // Add item to cart
    @PostMapping("/add")
    public ResponseEntity<?> addCartItem(@RequestBody AddCartItemRequest request) {
        try {
            CartItem item = cartItemService.addCartItem(
                request.getCartId(),
                request.getBookId(),
                request.getQuantity()
            );
            return ResponseEntity.ok(item);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    // Get item by ID
    @GetMapping("/{cartItemId}")
    public ResponseEntity<CartItem> getCartItemById(@PathVariable int cartItemId) {
        return ResponseEntity.ok(cartItemService.getCartItemById(cartItemId));
    }

    // Get all items by cart ID
    @GetMapping("/cart/{cartId}")
    public ResponseEntity<List<CartItem>> getItemsByCartId(@PathVariable int cartId) {
        return ResponseEntity.ok(cartItemService.getItemsByCartId(cartId));
    }

    // Update item quantity
    @PutMapping("/update/{cartItemId}")
    public ResponseEntity<CartItem> updateQuantity(@RequestBody UpdateQuantity request) {
        return ResponseEntity.ok(cartItemService.updateCartItemQuantity(request.getCartItemId(), request.getQuantity()));
    }

    // Delete item by ID
    @DeleteMapping("/{cartItemId}")
    public ResponseEntity<String> deleteCartItem(@PathVariable int cartItemId) {
        cartItemService.deleteCartItem(cartItemId);
        return ResponseEntity.ok("Deleted cart item with ID: " + cartItemId);
    }

    // Delete all items in a cart
    @DeleteMapping("/cart/{cartId}")
    public ResponseEntity<String> deleteAllItemsInCart(@PathVariable int cartId) {
        cartItemService.deleteItemsByCartId(cartId);
        return ResponseEntity.ok("Deleted all items in cart ID: " + cartId);
    }
}
