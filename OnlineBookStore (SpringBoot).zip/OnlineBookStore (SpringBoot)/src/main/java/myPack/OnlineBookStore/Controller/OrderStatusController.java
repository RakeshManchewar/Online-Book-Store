package myPack.OnlineBookStore.Controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import myPack.OnlineBookStore.Entity.OrderStatus;

@RestController
//@CrossOrigin("http://localhost:4200")
@RequestMapping("/api/order-statuses")
@CrossOrigin(origins = "*") // Allow CORS if you're using a frontend like Angular or React
public class OrderStatusController 
{
    // GET: List all available order statuses
    @GetMapping
    public ResponseEntity<OrderStatus[]> getAllOrderStatuses() {
        return ResponseEntity.ok(OrderStatus.values());
    }
}
