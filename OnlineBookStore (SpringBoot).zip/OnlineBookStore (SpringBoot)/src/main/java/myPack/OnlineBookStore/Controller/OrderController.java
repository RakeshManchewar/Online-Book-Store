package myPack.OnlineBookStore.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import myPack.OnlineBookStore.DTO.PlaceOrder;
import myPack.OnlineBookStore.DTO.UpdateStatus;
import myPack.OnlineBookStore.Entity.Order;
import myPack.OnlineBookStore.Entity.OrderStatus;
import myPack.OnlineBookStore.Service.OrderService;

@RestController
@CrossOrigin("http://localhost:4200")
@RequestMapping("/api/orders")
public class OrderController 
{
    @Autowired
    private OrderService orderService;

    // Place new order
    @PostMapping("/place")
    public ResponseEntity<Order> placeOrder(@RequestBody PlaceOrder request) {
        return ResponseEntity.ok(orderService.placeOrder(request.getUserId(), request.getTotalAmount()));
    }

    // Get all orders
    @GetMapping
    public ResponseEntity<List<Order>> getAllOrders() {
        return ResponseEntity.ok(orderService.getAllOrders());
    }

    // Get order by ID
    @GetMapping("/{orderId}")
    public ResponseEntity<Order> getOrderById(@PathVariable int orderId) {
        return ResponseEntity.ok(orderService.getOrderById(orderId));
    }

    // Get orders by user ID
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Order>> getOrdersByUserId(@PathVariable int userId) {
        return ResponseEntity.ok(orderService.getOrdersByUserId(userId));
    }

    // Get orders by status
    @GetMapping("/status/{status}")
    public ResponseEntity<List<Order>> getOrdersByStatus(@PathVariable String status) {
        return ResponseEntity.ok(orderService.getOrdersByStatus(status));
    }

    // Update order status
    @PutMapping("/update-status/{orderId}")
    public ResponseEntity<Order> updateOrderStatus(@RequestBody UpdateStatus request) {
        return ResponseEntity.ok(orderService.updateOrderStatus(request.getOrderId(), request.getStatus()));
    }

    // Delete order
    @DeleteMapping("/{orderId}")
    public ResponseEntity<String> deleteOrder(@PathVariable int orderId) {
        orderService.deleteOrder(orderId);
        return ResponseEntity.ok("Deleted order with ID: " + orderId);
    }
}
