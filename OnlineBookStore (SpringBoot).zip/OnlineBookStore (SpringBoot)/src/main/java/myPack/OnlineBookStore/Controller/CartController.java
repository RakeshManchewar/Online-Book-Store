package myPack.OnlineBookStore.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import myPack.OnlineBookStore.Entity.Cart;
import myPack.OnlineBookStore.Service.CartService;
import java.util.List;

@RestController
@CrossOrigin("http://localhost:4200")
@RequestMapping("/api/carts")
public class CartController {
    
    @Autowired
    private CartService cartService;
    
    // Create a cart for a user
    @PostMapping("/create/{userId}")
    public ResponseEntity<Cart> createCart(@PathVariable int userId) {
        try {
            Cart cart = cartService.createCart(userId);
            return ResponseEntity.ok(cart);
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }
    
    // Get cart by ID
    @GetMapping("/{cartId}")
    public ResponseEntity<Cart> getCartById(@PathVariable int cartId) {
        try {
            return ResponseEntity.ok(cartService.getCartById(cartId));
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    // Get cart by user ID - This should return existing cart or create new one
    @GetMapping("/user/{userId}")
    public ResponseEntity<Cart> getCartForUser(@PathVariable int userId) {
        try {
            System.out.println("API: Getting cart for user ID: " + userId);
            Cart cart = cartService.getOrCreateCart(userId);
            return ResponseEntity.ok(cart);
        } catch (Exception e) {
            System.err.println("Error getting cart for user " + userId + ": " + e.getMessage());
            return ResponseEntity.badRequest().build();
        }
    }
    
    // Get existing cart by user ID (without creating new one)
    @GetMapping("/user/{userId}/existing")
    public ResponseEntity<Cart> getExistingCartForUser(@PathVariable int userId) {
        try {
            Cart cart = cartService.getCartByUserId(userId);
            return ResponseEntity.ok(cart);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    // Get all carts
    @GetMapping
    public ResponseEntity<List<Cart>> getAllCarts() {
        return ResponseEntity.ok(cartService.getAllCarts());
    }
    
    // Delete a cart
    @DeleteMapping("/{cartId}")
    public ResponseEntity<String> deleteCart(@PathVariable int cartId) {
        try {
            cartService.deleteCart(cartId);
            return ResponseEntity.ok("Cart deleted with ID: " + cartId);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }
}