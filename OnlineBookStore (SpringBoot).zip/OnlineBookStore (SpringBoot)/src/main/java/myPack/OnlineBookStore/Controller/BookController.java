package myPack.OnlineBookStore.Controller;

import myPack.OnlineBookStore.Entity.Book;
import myPack.OnlineBookStore.DAO.BookDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@CrossOrigin("http://localhost:4200")
@RequestMapping("/api/books")
public class BookController 
{
    @Autowired
    private BookDAO bookDAO;
    
    // Get all books
    @GetMapping("/get/book")
    public ResponseEntity<List<Book>> getAllBooks() {
        try {
            List<Book> books = bookDAO.findAll();
            if (books.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<>(books, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Get book by ID
    @GetMapping("/{id}")
    public ResponseEntity<Book> getBookById(@PathVariable("id") int id) {
        Optional<Book> bookData = bookDAO.findById(id);
        return bookData.map(book -> new ResponseEntity<>(book, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    // Create new book
    @PostMapping("/save/book")
    public ResponseEntity<Book> createBook(@RequestBody Book book) {
        try {
            // Check if book with same title already exists
            Optional<Book> existingBook = bookDAO.findByBookTitle(book.getBookTitle());
            if (existingBook.isPresent()) {
                return new ResponseEntity<>(HttpStatus.CONFLICT);
            }
            
            Book newBook = bookDAO.save(new Book(
                    0, // ID will be auto-generated
                    book.getBookTitle(),
                    book.getBookAuthor(),
                    book.getPrice(),
                    book.getDescription(),
                    book.getAvailableStock()
            ));
            return new ResponseEntity<>(newBook, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Update book
    @PutMapping("/update/book/{id}")
    public ResponseEntity<Book> updateBook(@PathVariable("id") int id, @RequestBody Book book) {
        Optional<Book> bookData = bookDAO.findById(id);
        if (bookData.isPresent()) {
            Book existingBook = bookData.get();
            existingBook.setBookTitle(book.getBookTitle());
            existingBook.setBookAuthor(book.getBookAuthor());
            existingBook.setPrice(book.getPrice());
            existingBook.setDescription(book.getDescription());
            existingBook.setAvailableStock(book.getAvailableStock());
            
            return new ResponseEntity<>(bookDAO.save(existingBook), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // Delete book
    @DeleteMapping("/delete/book/{id}")
    public ResponseEntity<HttpStatus> deleteBook(@PathVariable("id") int id) {
        try {
            bookDAO.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Search by title containing keyword (case-insensitive)
    @GetMapping("/search/book/title/{keyword}")
    public ResponseEntity<List<Book>> searchByTitlePath(@PathVariable("keyword") String keyword) {
        try {
            List<Book> books = bookDAO.findByBookTitleContainingIgnoreCase(keyword);
            if (books.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<>(books, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Search by author containing keyword (case-insensitive)
    @GetMapping("/search/book/author/{keyword}")
    public ResponseEntity<List<Book>> searchByAuthor(@PathVariable("keyword") String keyword) {
        try {
            List<Book> books = bookDAO.findByBookAuthorContainingIgnoreCase(keyword);
            if (books.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<>(books, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Search by maximum price
    @GetMapping("/search/book/price/{maxPrice}")
    public ResponseEntity<List<Book>> searchByMaxPrice(@PathVariable("maxPrice") int maxPrice) {
        try {
            List<Book> books = bookDAO.findByPriceLessThanEqual(maxPrice);
            if (books.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<>(books, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Search by minimum available stock
    @GetMapping("/search/book/stock/{minStock}")
    public ResponseEntity<List<Book>> searchByMinStock(@PathVariable("minStock") int minStock) {
        try {
            List<Book> books = bookDAO.findByAvailableStockGreaterThan(minStock);
            if (books.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<>(books, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}