package myPack.OnlineBookStore.Controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import myPack.OnlineBookStore.Entity.Role;
import myPack.OnlineBookStore.Entity.User;
import myPack.OnlineBookStore.Service.RoleService;

@CrossOrigin("http://localhost:4200")
@RestController
@RequestMapping("/api/roles")
public class RoleController 
{
    @Autowired
    private RoleService roleService;
    
    @PostMapping("/createNewRole")
    public Role createNewRole(@RequestBody Role role) {
        return roleService.createNewRole(role);
    }
    
    @GetMapping("/all")
    public ResponseEntity<List<Role>> getAllRoles() {
        return ResponseEntity.ok(roleService.getAllRoles());
    }
    
    @GetMapping("/{roleName}")
    public ResponseEntity<Role> getRoleByName(@PathVariable String roleName) {
        return ResponseEntity.ok(roleService.getRoleByName(roleName));
    }
    
    @GetMapping("/{roleName}/users")
    public ResponseEntity<List<User>> getUsersForRole(@PathVariable String roleName) {
        return ResponseEntity.ok(roleService.getUsersForRole(roleName));
    }
    
    @GetMapping("/{roleName}/user-count")
    public ResponseEntity<Integer> getUserCountForRole(@PathVariable String roleName) {
        return ResponseEntity.ok(roleService.getUserCountForRole(roleName));
    }
    
    @PutMapping("/{roleName}")
    public ResponseEntity<Role> updateRoleDescription(@PathVariable String roleName, 
                                                     @RequestParam String description) {
        return ResponseEntity.ok(roleService.updateRoleDescription(roleName, description));
    }
    
    @DeleteMapping("/{roleName}")
    public ResponseEntity<String> deleteRole(@PathVariable String roleName) {
        roleService.deleteRole(roleName);
        return ResponseEntity.ok("Role deleted: " + roleName);
    }
    
    @GetMapping("/{roleName}/exists")
    public ResponseEntity<Boolean> roleExists(@PathVariable String roleName) {
        return ResponseEntity.ok(roleService.roleExists(roleName));
    }
}
