package myPack.OnlineBookStore.DTO;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;

public class LoginRequest {
    
    @NotEmpty(message = "Email is required")
    @Email(message = "Email should be valid")
    private String userEmail;
    
    @NotEmpty(message = "Password is required")
    private String userPassword;
    
    // Default constructor
    public LoginRequest() {
    }
    
    // Parameterized constructor
    public LoginRequest(String userEmail, String userPassword) {
        this.userEmail = userEmail;
        this.userPassword = userPassword;
    }
    
    // Getters and Setters
    public String getUserEmail() {
        return userEmail;
    }
    
    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }
    
    public String getUserPassword() {
        return userPassword;
    }
    
    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }
    
    @Override
    public String toString() {
        return "LoginRequest [userEmail=" + userEmail + ", userPassword=***]";
    }
}