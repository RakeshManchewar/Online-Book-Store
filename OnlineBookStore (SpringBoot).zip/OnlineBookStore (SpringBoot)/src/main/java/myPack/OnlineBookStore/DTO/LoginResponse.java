package myPack.OnlineBookStore.DTO;

public class LoginResponse 
{
    private String token;
    private Integer userId;
    private String message;
    private String status;
    private String userEmail;
    private String userName;
    
    // Default constructor
    public LoginResponse() {}
    
    // Constructor with all fields
    public LoginResponse(String token, Integer userId, String message, String status, String userEmail, String userName) {
        this.token = token;
        this.userId = userId;
        this.message = message;
        this.status = status;
        this.userEmail = userEmail;
        this.userName = userName;
    }
    
    // Getters and Setters
    public String getToken() {
        return token;
    }
    
    public void setToken(String token) {
        this.token = token;
    }
    
    public Integer getUserId() {
        return userId;
    }
    
    public void setUserId(Integer userId) {
        this.userId = userId;
    }
    
    public String getMessage() {
        return message;
    }
    
    public void setMessage(String message) {
        this.message = message;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public String getUserEmail() {
        return userEmail;
    }
    
    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }
    
    public String getUserName() {
        return userName;
    }
    
    public void setUserName(String userName) {
        this.userName = userName;
    }
}
