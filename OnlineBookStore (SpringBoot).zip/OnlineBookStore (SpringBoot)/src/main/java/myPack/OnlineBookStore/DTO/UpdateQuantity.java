package myPack.OnlineBookStore.DTO;

public class UpdateQuantity 
{
	private int cartItemId;
	private int quantity;
	
	public int getCartItemId() {
		return cartItemId;
	}
	public void setCartItemId(int cartItemId) {
		this.cartItemId = cartItemId;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	public UpdateQuantity(int cartItemId, int quantity) {
		super();
		this.cartItemId = cartItemId;
		this.quantity = quantity;
	}
	
	public UpdateQuantity() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		return "UpdateQuantity [cartItemId=" + cartItemId + ", quantity=" + quantity + "]";
	}
}
