package myPack.OnlineBookStore.DTO;

public class PaymentResponse 
{
    private String orderId;
    private String currency;
    private double amount;
    private String key;
    private String status;

    // Getters and Setters
    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    // Constructors
    public PaymentResponse() {
    }

    public PaymentResponse(String orderId, String currency, double amount, String key, String status) {
        this.orderId = orderId;
        this.currency = currency;
        this.amount = amount;
        this.key = key;
        this.status = status;
    }
}
