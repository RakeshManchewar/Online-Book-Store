package myPack.OnlineBookStore.DTO;

public class PaymentRequest 
{
    private int userId;
    private double amount;
    private String currency;
    private String receipt;

    // Getters and Setters
    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getReceipt() {
        return receipt;
    }

    public void setReceipt(String receipt) {
        this.receipt = receipt;
    }

    // Constructors
    public PaymentRequest() {
    }

    public PaymentRequest(int userId, double amount, String currency, String receipt) {
        this.userId = userId;
        this.amount = amount;
        this.currency = currency;
        this.receipt = receipt;
    }
}
