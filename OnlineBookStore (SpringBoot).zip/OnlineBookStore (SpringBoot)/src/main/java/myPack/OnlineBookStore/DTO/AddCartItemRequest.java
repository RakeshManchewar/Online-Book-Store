package myPack.OnlineBookStore.DTO;

public class AddCartItemRequest 
{
    private int cartId;
    private int bookId;
    private int quantity;
    
	public int getCartId() {
		return cartId;
	}
	public void setCartId(int cartId) {
		this.cartId = cartId;
	}
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	public AddCartItemRequest(int cartId, int bookId, int quantity) {
		super();
		this.cartId = cartId;
		this.bookId = bookId;
		this.quantity = quantity;
	}
	
	public AddCartItemRequest() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		return "AddCartItemRequest [cartId=" + cartId + ", bookId=" + bookId + ", quantity=" + quantity + "]";
	}
}
