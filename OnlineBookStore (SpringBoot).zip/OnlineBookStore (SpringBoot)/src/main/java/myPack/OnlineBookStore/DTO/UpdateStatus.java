package myPack.OnlineBookStore.DTO;

import myPack.OnlineBookStore.Entity.OrderStatus;

public class UpdateStatus 
{
	private int orderId;
	private OrderStatus status;
	
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public OrderStatus getStatus() {
		return status;
	}
	public void setStatus(OrderStatus status) {
		this.status = status;
	}
	
	public UpdateStatus(int orderId, OrderStatus status) {
		super();
		this.orderId = orderId;
		this.status = status;
	}
	
	public UpdateStatus() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		return "UpdateStatus [orderId=" + orderId + ", status=" + status + "]";
	}
}
