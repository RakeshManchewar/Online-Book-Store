package myPack.OnlineBookStore.DTO;

public class PlaceOrder 
{
	private int userId;
	private int totalAmount;
	
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(int totalAmount) {
		this.totalAmount = totalAmount;
	}
	
	public PlaceOrder(int userId, int totalAmount) {
		super();
		this.userId = userId;
		this.totalAmount = totalAmount;
	}
	
	public PlaceOrder() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		return "PlaceOrder [userId=" + userId + ", totalAmount=" + totalAmount + "]";
	}
}
