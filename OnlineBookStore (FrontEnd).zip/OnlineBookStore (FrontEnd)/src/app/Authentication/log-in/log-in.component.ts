import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { AuthService } from '../../auth.service';

interface LoginResponse {
  token: string;
  userId: number;
  message: string;
  status: string;
  userEmail: string;
  userName: string;
}

@Component({
  selector: 'app-log-in',
  standalone: false,
  templateUrl: './log-in.component.html',
  styleUrls: ['./log-in.component.css']
})
export class LogInComponent {
  loginRequest = {
    userEmail: '',
    userPassword: ''
  };

  errorMessage: string = '';

  // Admin credentials
  private adminCredentials = {
    userEmail: 'admin@gmail.com',
    userPassword: 'Admin@123',
    userId: 1
  };

  constructor(
    private http: HttpClient,
    private router: Router,
    private authService: AuthService
  ) {}

  onSubmit(): void {
    this.errorMessage = '';

    if (!this.loginRequest.userEmail || !this.loginRequest.userPassword) {
      this.errorMessage = 'Please fill in all fields';
      Swal.fire('Error', this.errorMessage, 'error');
      return;
    }

    // Check if admin credentials
    if (this.loginRequest.userEmail === this.adminCredentials.userEmail && 
        this.loginRequest.userPassword === this.adminCredentials.userPassword) {
      console.log('Admin login detected');
      this.authService.login('admin_token', 'admin', this.adminCredentials.userId);
      Swal.fire('Success', 'Admin login successful', 'success').then(() => {
        this.router.navigate(['/admin-dashboard']);
      });
      return;
    }

    // Regular user login
    console.log('Attempting user login for:', this.loginRequest.userEmail);
    
    this.http.post<LoginResponse>('http://localhost:8080/api/users/login', this.loginRequest)
      .subscribe({
        next: (response) => {
          console.log('Login response received:', response);
          
          if (response.status === 'success' && response.userId && response.token) {
            // Store auth information
            this.authService.login(response.token, 'user', response.userId);
            
            // Debug: Verify what was stored
            console.log('After login - Auth state:');
            this.authService.debugAuthState();
            
            Swal.fire('Success', response.message || 'Login successful', 'success').then(() => {
              this.router.navigate(['/user-dashboard']);
            });
          } else {
            this.errorMessage = response.message || 'Login failed';
            Swal.fire('Error', this.errorMessage, 'error');
          }
        },
        error: (err) => {
          console.error('Login error:', err);
          
          if (err.status === 400) {
            // Backend returned error response
            if (err.error && err.error.message) {
              this.errorMessage = err.error.message;
            } else {
              this.errorMessage = 'Invalid email or password';
            }
            Swal.fire('Error', this.errorMessage, 'error');
          } else if (err.status === 0) {
            this.errorMessage = 'Cannot connect to server. Please check if the server is running.';
            Swal.fire('Error', this.errorMessage, 'error');
          } else {
            this.errorMessage = 'An error occurred. Please try again later.';
            Swal.fire('Error', this.errorMessage, 'error');
          }
        }
      });
  }

  // Debug methods (remove in production)
  debugAuth(): void {
    this.authService.debugAuthState();
  }

  clearAuth(): void {
    this.authService.clearAllAuthData();
    console.log('Auth data cleared');
  }
}
