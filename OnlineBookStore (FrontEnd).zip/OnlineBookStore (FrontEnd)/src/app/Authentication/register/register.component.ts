import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-register',
  standalone: false,
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {
  user = {
      userName: '',
      userEmail: '',
      userPassword: '',
    };
    
    constructor(private http: HttpClient, private router: Router) {}

    register() {
      this.http.post('http://localhost:8080/api/users/register', this.user).subscribe(
        (response: any) => {
          Swal.fire('success', 'Registration successfull Please log in.', 'success').then(() => {
            // Navigate to login page after successful registration
            this.router.navigate(['/LogIn']);
          });
        },
        (error) => {
          Swal.fire('error', 'user already exists or invalid input!', 'error');
        }
    );
}
}
