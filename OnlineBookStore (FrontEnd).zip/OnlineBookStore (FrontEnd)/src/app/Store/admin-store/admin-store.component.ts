import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-store',
  standalone: false,
  templateUrl: './admin-store.component.html',
  styleUrl: './admin-store.component.css'
})
export class AdminStoreComponent {

}
