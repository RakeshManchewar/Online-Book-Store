import { Component } from '@angular/core';

@Component({
  selector: 'app-user-store',
  standalone: false,
  templateUrl: './user-store.component.html',
  styleUrl: './user-store.component.css'
})
export class UserStoreComponent {

}
