import { Injectable } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})

export class NavigationService {
  private previousUrl: string = '';
  private currentUrl: string = '';

  constructor(
    private router: Router,
    private authService: AuthService
  ) {
    this.trackNavigation();
  }

  private trackNavigation(): void {
    this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe((event: NavigationEnd) => {
        this.previousUrl = this.currentUrl;
        this.currentUrl = event.url;
      });
  }

  navigateToBookShelf(): void {
    const role = this.authService.getUserRole();
    const bookShelfUrl = this.getBookShelfUrlForRole(role);
    
    // Check if previous URL was a book shelf page for the same role
    if (this.isBookShelfUrlForRole(this.previousUrl, role)) {
      this.router.navigateByUrl(this.previousUrl);
    } else {
      this.router.navigate([bookShelfUrl]);
    }
  }

  private getBookShelfUrlForRole(role: string): string {
    return `/${this.getRolePrefix(role)}-Book-Shelf`;
  }

  private isBookShelfUrlForRole(url: string, role: string): boolean {
    return url.startsWith(this.getBookShelfUrlForRole(role));
  }

  private getRolePrefix(role: string): string {
    return role.charAt(0).toUpperCase() + role.slice(1);
  }
}
