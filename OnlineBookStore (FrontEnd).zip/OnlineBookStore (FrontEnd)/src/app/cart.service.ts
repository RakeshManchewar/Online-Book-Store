import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { catchError, map, Observable, of, switchMap, throwError } from 'rxjs';
import { Cart, CartItem, AddCartItemRequest, UpdateQuantity } from './cart';
import { Book } from './book';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class CartService {
  private apiUrl = 'http://localhost:8080/api';

  constructor(
    private http: HttpClient,
    private authService: AuthService
  ) { }

  createCart(userId: number): Observable<Cart> {
    console.log('Creating cart for user:', userId);
    return this.http.post<Cart>(`${this.apiUrl}/carts/create/${userId}`, {}).pipe(
      catchError(error => {
        console.error('Error creating cart:', error);
        return throwError(() => new Error('Failed to create cart'));
      })
    );
  }

  getCartById(cartId: number): Observable<Cart> {
    return this.http.get<Cart>(`${this.apiUrl}/carts/${cartId}`).pipe(
      catchError(error => {
        console.error('Error fetching cart by ID:', error);
        return throwError(() => new Error('Failed to load cart'));
      })
    );
  }

  getCartByUserId(userId: number): Observable<Cart> {
    console.log('Getting cart for user:', userId);
    return this.http.get<Cart>(`${this.apiUrl}/carts/user/${userId}`).pipe(
      catchError(error => {
        console.error('Error fetching cart for user:', userId, error);
        if (error.status === 404) {
          console.log('Cart not found, will be created by backend');
        }
        return throwError(() => error);
      })
    );
  }

  deleteCart(cartId: number): Observable<string> {
    return this.http.delete<string>(`${this.apiUrl}/carts/${cartId}`);
  }

  addCartItem(request: AddCartItemRequest): Observable<CartItem> {
    console.log('Adding cart item:', request);
    return this.http.post<CartItem>(`${this.apiUrl}/cart-items/add`, request).pipe(
      catchError(error => {
        console.error('Error adding cart item:', error);
        return throwError(() => new Error('Failed to add item to cart'));
      })
    );
  }

  getCartItemById(cartItemId: number): Observable<CartItem> {
    return this.http.get<CartItem>(`${this.apiUrl}/cart-items/${cartItemId}`);
  }

  getItemsByCartId(cartId: number): Observable<CartItem[]> {
    console.log('Getting items for cart:', cartId);
    return this.http.get<CartItem[]>(`${this.apiUrl}/cart-items/cart/${cartId}`).pipe(
      catchError(error => {
        console.error('Error getting cart items:', error);
        return of([]);
      })
    );
  }

  updateQuantity(request: UpdateQuantity): Observable<CartItem> {
    return this.http.put<CartItem>(`${this.apiUrl}/cart-items/update/${request.cartItemId}`, request);
  }

  deleteCartItem(cartItemId: number): Observable<void> {
    return this.http.delete(`${this.apiUrl}/cart-items/${cartItemId}`, {
      responseType: 'text'
    }).pipe(
      map(() => {
        return;
      }),
      catchError(error => {
        console.error('API Error:', error);
        return throwError(() => 
          error.error?.message || 
          error.message || 
          'Failed to remove item from server'
        );
      })
    );
  }
  
  deleteAllItemsInCart(cartId: number): Observable<boolean> {
    return this.http.delete(`${this.apiUrl}/cart-items/cart/${cartId}`, { 
      responseType: 'text'
    }).pipe(
      map(() => {
        return true;
      }),
      catchError(error => {
        console.error('Clear Cart Error:', error);
        return of(false);
      })
    );
  }

  getOrCreateCartForUser(userId: number): Observable<Cart> {
    console.log('Getting or creating cart for user:', userId);
    return this.http.get<Cart>(`${this.apiUrl}/carts/user/${userId}`).pipe(
      catchError(err => {
        console.error('Error getting cart for user:', userId, err);
        let errorMsg = 'Failed to access your cart';
        if (err.status === 404) {
          errorMsg = 'Your shopping cart could not be located';
        } else if (err.status === 403) {
          errorMsg = 'Please log in to access your cart';
        }
        return throwError(() => new Error(errorMsg));
      })
    );
  }

  syncLocalCartWithBackend(userId: number): Observable<CartItem[]> {
    return throwError(() => new Error('Local cart functionality disabled'));
  }
}
