import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-cart',
  standalone: false,
  templateUrl: './admin-cart.component.html',
  styleUrl: './admin-cart.component.css'
})
export class AdminCartComponent {

}
