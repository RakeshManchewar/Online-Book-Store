import { Component } from '@angular/core';

@Component({
  selector: 'app-user-cart',
  standalone: false,
  templateUrl: './user-cart.component.html',
  styleUrl: './user-cart.component.css'
})
export class UserCartComponent {

}
