import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AuthService } from './auth.service';
import { environment } from '../environment/environment';

interface PaymentResponse {
  orderId: string;
  currency: string;
  amount: number;
  key: string;
  status: string;
}

@Injectable({
  providedIn: 'root'
})
export class PaymentService {
  private apiUrl = environment.apiUrl;

  constructor(
    private http: HttpClient,
    private authService: AuthService
  ) {}

  createOrder(amount: number) {
    const userId = this.authService.getCurrentUserId();
    if (!userId) {
      throw new Error('User not logged in');
    }

    const paymentRequest = {
      userId: userId,
      amount: amount,
      currency: 'INR',
      receipt: `order_${Date.now()}`
    };

    return this.http.post<PaymentResponse>(`${this.apiUrl}/payment/create-order`, paymentRequest);
  }

  verifyPayment(orderId: string, paymentId: string, signature: string) {
    const userId = this.authService.getCurrentUserId();
    if (!userId) {
      throw new Error('User not logged in');
    }

    const verificationData = {
      razorpayOrderId: orderId,
      razorpayPaymentId: paymentId,
      razorpaySignature: signature,
      userId: userId
    };

    return this.http.post(`${this.apiUrl}/payment/verify`, verificationData, { responseType: 'text' });
  }
}
