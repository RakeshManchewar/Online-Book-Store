import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GuestBookShelfComponent } from './guest-book-shelf.component';

describe('GuestBookShelfComponent', () => {
  let component: GuestBookShelfComponent;
  let fixture: ComponentFixture<GuestBookShelfComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [GuestBookShelfComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GuestBookShelfComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
