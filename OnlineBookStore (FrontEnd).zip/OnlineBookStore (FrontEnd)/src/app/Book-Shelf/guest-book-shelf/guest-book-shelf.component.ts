import { Component } from '@angular/core';

@Component({
  selector: 'app-guest-book-shelf',
  standalone: false,
  templateUrl: './guest-book-shelf.component.html',
  styleUrl: './guest-book-shelf.component.css'
})
export class GuestBookShelfComponent {

}
