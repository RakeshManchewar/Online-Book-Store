import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminBookShelfComponent } from './admin-book-shelf.component';

describe('AdminBookShelfComponent', () => {
  let component: AdminBookShelfComponent;
  let fixture: ComponentFixture<AdminBookShelfComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AdminBookShelfComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminBookShelfComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
