import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-book-shelf',
  standalone: false,
  templateUrl: './admin-book-shelf.component.html',
  styleUrl: './admin-book-shelf.component.css'
})
export class AdminBookShelfComponent {

}
