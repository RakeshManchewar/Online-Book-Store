import { Component } from '@angular/core';

@Component({
  selector: 'app-user-book-shelf',
  standalone: false,
  templateUrl: './user-book-shelf.component.html',
  styleUrl: './user-book-shelf.component.css'
})
export class UserBookShelfComponent {

}
