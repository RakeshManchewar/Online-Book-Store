import { Injectable, Inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private tokenKey = 'auth_token';
  private roleKey = 'user_role';
  private userIdKey = 'user_id';

  constructor(@Inject(PLATFORM_ID) private platformId: Object) {}

  login(token: string, role: string, userId?: number, userName?: string, userEmail?: string): void {
    this.setToken(token);
    this.setUserRole(role);
    if (userId) {
      this.setCurrentUserId(userId);
    }
    if (userName) {
      this.setInStorage('user_name', userName);
    }
    if (userEmail) {
      this.setInStorage('user_email', userEmail);
    }
  }

  logout(): void {
    this.removeToken();
    this.removeUserRole();
    this.removeCurrentUserId();
  }

  getToken(): string | null {
    return this.getFromStorage(this.tokenKey);
  }

  private setToken(token: string): void {
    this.setInStorage(this.tokenKey, token);
  }

  private removeToken(): void {
    this.removeFromStorage(this.tokenKey);
  }

  getUserRole(): string {
    return this.getFromStorage(this.roleKey) || 'guest';
  }

  private setUserRole(role: string): void {
    this.setInStorage(this.roleKey, role);
  }

  private removeUserRole(): void {
    this.removeFromStorage(this.roleKey);
  }

  getCurrentUserId(): number | null {
    const id = this.getFromStorage(this.userIdKey);
    return id ? parseInt(id) : null;
  }

  private setCurrentUserId(userId: number): void {
    this.setInStorage(this.userIdKey, userId.toString());
  }

  private removeCurrentUserId(): void {
    this.removeFromStorage(this.userIdKey);
  }

  isLoggedIn(): boolean {
    return this.getToken() !== null;
  }

  isAdmin(): boolean {
    return this.getUserRole() === 'admin';
  }

  isUser(): boolean {
    return this.getUserRole() === 'user';
  }

  debugAuthState(): void {
    console.log('=== Auth State Debug ===');
    console.log('Token:', this.getToken());
    console.log('Role:', this.getUserRole());
    console.log('User ID:', this.getCurrentUserId());
    console.log('Is Logged In:', this.isLoggedIn());
    console.log('Is Admin:', this.isAdmin());
    console.log('Is User:', this.isUser());
    console.log('========================');
  }

  clearAllAuthData(): void {
    this.removeToken();
    this.removeUserRole();
    this.removeCurrentUserId();
    console.log('All auth data cleared');
  }

  private getFromStorage(key: string): string | null {
    if (isPlatformBrowser(this.platformId)) {
      return localStorage.getItem(key);
    }
    return null;
  }

  private setInStorage(key: string, value: string): void {
    if (isPlatformBrowser(this.platformId)) {
      localStorage.setItem(key, value);
    }
  }

  private removeFromStorage(key: string): void {
    if (isPlatformBrowser(this.platformId)) {
      localStorage.removeItem(key);
    }
  }

  getCurrentUserName(): string | null {
    return this.getFromStorage('user_name');
  }

  getCurrentUserEmail(): string | null {
    return this.getFromStorage('user_email');
  }
}
