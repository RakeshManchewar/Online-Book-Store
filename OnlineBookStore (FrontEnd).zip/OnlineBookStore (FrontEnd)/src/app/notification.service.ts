import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})

export class NotificationService {
  constructor() { }

  showLoading(message: string): { close: () => void } {
    // Implement with your preferred loading indicator
    console.log('Loading:', message);
    return {
      close: () => console.log('Loading closed')
    };
  }

  showSuccess(message: string): void {
    alert('Success: ' + message); // Replace with toast notification
  }

  showError(message: string): void {
    alert('Error: ' + message); // Replace with error dialog
  }
}