// cart.component.ts
import { Component, OnInit } from '@angular/core';
import { CartService } from '../../cart.service';
import { Cart, CartItem, UpdateQuantity } from '../../cart';
import { AuthService } from '../../auth.service';
import Swal from 'sweetalert2';
import { BooksService } from '../../books.service';
import { PaymentService } from '../../payment.service';
import { Router } from '@angular/router';

declare var Razorpay: any; // This will now use your custom typings

@Component({
  selector: 'app-cart',
  standalone: false,
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})

export class CartComponent implements OnInit {
  cart: Cart | null = null;
  cartItems: CartItem[] = [];
  totalPrice: number = 0;
  loading: boolean = true;
  error: string | null = null;

  constructor(
    private booksService: BooksService,
    private cartService: CartService,
    private authService: AuthService,
    private paymentService: PaymentService,
    private router: Router
  ) {}

  ngOnInit(): void {
    console.log('Initializing cart component');
    this.loadCart();
  }

  loadCart(): void {
    console.log('Loading cart...');
    const userId = this.authService.getCurrentUserId();
    if (!userId) {
      this.error = 'User not logged in';
      this.loading = false;
      return;
    }

    this.cartService.getCartByUserId(userId).subscribe({
      next: (cart) => {
        this.cart = cart;
        this.loadCartItems(cart.cartId);
      },
      error: (err) => {
        if (err.status === 404) {
          this.createCart(userId);
        } else {
          this.error = 'Failed to load cart';
          this.loading = false;
        }
      }
    });
  }

  createCart(userId: number): void {
    this.cartService.createCart(userId).subscribe({
      next: (cart) => {
        this.cart = cart;
        this.loadCartItems(cart.cartId);
      },
      error: (err) => {
        this.error = 'Failed to create cart';
        this.loading = false;
      }
    });
  }

  loadCartItems(cartId: number): void {
    this.cartService.getItemsByCartId(cartId).subscribe({
      next: (items) => {
        this.cartItems = items;
        this.calculateTotal();
        this.loading = false;
      },
      error: (err) => {
        this.error = 'Failed to load cart items';
        this.loading = false;
      }
    });
  }

  calculateTotal(): void {
    this.totalPrice = this.cartItems.reduce((total, item) => {
      return total + (item.book.price * item.quantity);
    }, 0);
  }

  updateQuantity(item: CartItem, newQuantity: number): void {
    if (newQuantity < 1) return;

    const request: UpdateQuantity = {
      cartItemId: item.cartItemId,
      quantity: newQuantity
    };

    this.cartService.updateQuantity(request).subscribe({
      next: (updatedItem) => {
        const index = this.cartItems.findIndex(i => i.cartItemId === updatedItem.cartItemId);
        if (index !== -1) {
          this.cartItems[index] = updatedItem;
          this.calculateTotal();
        }
      },
      error: (err) => {
        this.error = 'Failed to update quantity';
      }
    });
  }

  removeItem(cartItemId: number): void {
    console.log('Attempting to remove item:', cartItemId);
    this.loading = true;
    const originalItems = [...this.cartItems];
    
    this.cartService.deleteCartItem(cartItemId).subscribe({
      next: () => {
        this.cartItems = this.cartItems.filter(item => item.cartItemId !== cartItemId);
        this.calculateTotal();
        this.error = null; // Explicitly clear any previous errors
        this.loading = false;
        
        Swal.fire({
          title: 'Success',
          text: 'Item removed from cart',
          icon: 'success'
        });
      },
      error: (err) => {
        console.error('Error removing item:', err);
        this.cartItems = originalItems;
        this.error = 'Failed to remove item. Please try again.';
        this.loading = false;
        
        Swal.fire({
          title: 'Error',
          text: this.error,
          icon: 'error'
        });
      }
    });
  }

  clearCart(): void {
    console.log('1. Starting clearCart');
    
    if (!this.cart) {
      console.log('2. No cart available');
      return;
    }

    this.loading = true;
    this.error = null; // Explicitly clear previous errors
    
    console.log('3. Calling service with cartId:', this.cart.cartId);
    
    this.cartService.deleteAllItemsInCart(this.cart.cartId).subscribe({
      next: (success) => {
        console.log('4. Service response:', success);
        this.loading = false;
        
        if (success) {
          this.cartItems = [];
          this.totalPrice = 0;
          console.log('5. Cart cleared successfully');
          Swal.fire('Success', 'Cart cleared successfully', 'success');
        } else {
          this.error = 'Failed to clear cart';
          console.log('6. Service returned failure');
          Swal.fire('Error', this.error, 'error');
        }
      },
      error: (err) => {
        console.log('7. Service error:', err);
        this.loading = false;
        this.error = 'Unexpected error occurred';
        console.error('Unexpected error:', err);
        Swal.fire('Error', this.error, 'error');
      }
    });
  }

  proceedToCheckout(): void {
    if (this.totalPrice <= 0) {
      Swal.fire('Error', 'Cannot checkout with empty cart', 'error');
      return;
    }

    this.paymentService.createOrder(this.totalPrice).subscribe({
      next: (response) => {
        this.openRazorpayPayment(response);
      },
      error: (err) => {
        Swal.fire('Error', 'Failed to create payment order', 'error');
        console.error(err);
      }
    });
  }

  // Update the openRazorpayPayment method in cart.component.ts
  private openRazorpayPayment(paymentResponse: any): void {
    const options = {
      key: paymentResponse.key,
      amount: paymentResponse.amount * 100, // amount in paise
      currency: paymentResponse.currency,
      name: 'Online Book Store',
      description: 'Purchase of Books',
      image: 'assets/logo.png', // path to your logo
      order_id: paymentResponse.orderId,
      handler: (response: any) => {
        this.verifyPayment(response, paymentResponse.orderId);
      },
      prefill: {
        name: this.authService.getCurrentUserName() || 'Customer',
        email: this.authService.getCurrentUserEmail() || 'customer@example.com'
      },
      notes: {
        address: 'Book Store Office'
      },
      theme: {
        color: '#3399cc'
      }
    };

    const rzp = new Razorpay(options);
    rzp.open();
  }

  private verifyPayment(response: any, orderId: string): void {
    this.paymentService.verifyPayment(
      orderId,
      response.razorpay_payment_id,
      response.razorpay_signature
    ).subscribe({
      next: () => {
        Swal.fire('Success', 'Payment successful! Your order has been placed.', 'success').then(() => {
          // Clear cart and redirect to orders page
          this.clearCart();
          this.router.navigate(['/orders']);
        });
      },
      error: (err) => {
        Swal.fire('Error', 'Payment verification failed. Please contact support.', 'error');
        console.error(err);
      }
    });
  }
}
