import { Component, OnInit } from '@angular/core';
import { UserService } from '../../users.service';
import { User } from '../../users';
import { AuthService } from '../../auth.service';

@Component({
  selector: 'app-users',
  standalone: false,
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})

export class UsersComponent implements OnInit {
  users: User[] = [];
  editableUser: User | null = null;
  loading = true;
  error: string | null = null;

  constructor(
    private userService: UserService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this.loadUsers();
  }

  loadUsers(): void {
    this.userService.getAllUsers().subscribe({
      next: (data) => this.users = data,
      error: (err) => console.error('Error fetching users:', err)
    });
  }

  editUser(user: User): void {
    this.editableUser = { ...user };
  }

  saveUser(): void {
    if (!this.editableUser) return;

    const userId = this.editableUser.userId;
    this.userService.updateUser(userId, this.editableUser).subscribe({
      next: (updatedUser) => {
        const index = this.users.findIndex(u => u.userId === userId);
        if (index !== -1) {
          this.users[index] = updatedUser;
        }
        this.editableUser = null;
      },
      error: (err) => console.error('Error updating user:', err)
    });
  }

  cancelEdit(): void {
    this.editableUser = null;
  }

  deleteUser(userId: number): void {
    if (confirm('Are you sure you want to delete this user?')) {
      this.userService.deleteUser(userId).subscribe({
        next: () => {
          this.users = this.users.filter(u => u.userId !== userId);
        },
        error: (err) => console.error('Error deleting user:', err)
      });
    }
  }
}