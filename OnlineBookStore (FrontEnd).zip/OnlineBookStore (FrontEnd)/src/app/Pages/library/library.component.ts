import { Component, NgModule, OnInit } from '@angular/core'; // Import OnInit if you use it
import { Book } from '../../book';
import { BooksService } from '../../books.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http'; // <--- Add this import

@Component({
  selector: 'app-library',
  // Make consistent with your decision about standalone components
  standalone: false,  // Set to "true" if choosing Option 1, "false" if choosing Option 2
  templateUrl: './library.component.html',
  styleUrls: ['./library.component.css']
})

export class LibraryComponent implements OnInit { // Implement OnInit
  books: Book[] = [];
  editableBook: Book | null = null;

  constructor(private bookService: BooksService) {}

  ngOnInit(): void {
    this.loadBooks();
  }

  loadBooks(): void {
    this.bookService.getBooks().subscribe({
      next: (data) => this.books = data,
      error: (err) => console.error('Error fetching books:', err)
    });
  }

  editBook(book: Book): void {
    this.editableBook = { ...book };
  }

  saveBook(): void {
    if (!this.editableBook) return;

    const bookId = this.editableBook.bookId;
    this.bookService.updateBook(bookId, this.editableBook).subscribe({
      next: (updatedBook) => {
        const index = this.books.findIndex(b => b.bookId === bookId);
        if (index !== -1) {
          this.books[index] = updatedBook;
        }
        this.editableBook = null;
      },
      error: (err) => console.error('Error updating book:', err)
    });
  }

  cancelEdit(): void {
    this.editableBook = null;
  }

  deleteBook(bookId: number): void {
    if (confirm('Are you sure you want to delete this book?')) {
      this.bookService.deleteBook(bookId).subscribe({
        next: () => {
          this.books = this.books.filter(b => b.bookId !== bookId);
        },
        error: (err) => console.error('Error deleting book:', err)
      });
    }
  }
}