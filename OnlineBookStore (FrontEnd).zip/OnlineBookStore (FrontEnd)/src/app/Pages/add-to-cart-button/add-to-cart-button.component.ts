import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CartService } from '../../cart.service';
import { AuthService } from '../../auth.service';

@Component({
  selector: 'app-add-to-cart-button',
  standalone: false,
  template: `
    <button (click)="addToCart()" class="add-to-cart-btn" [disabled]="loading">
      {{ loading ? 'Adding...' : 'Add to Cart' }}
    </button>
  `,
  styles: [`
    .add-to-cart-btn {
      background-color: #4CAF50;
      color: white;
      border: none;
      padding: 0.5rem 1rem;
      border-radius: 4px;
      cursor: pointer;
      transition: background-color 0.3s;
      font-size: 0.9rem;
    }
    
    .add-to-cart-btn:hover:not(:disabled) {
      background-color: #45a049;
    }
    
    .add-to-cart-btn:disabled {
      background-color: #cccccc;
      cursor: not-allowed;
    }
  `]
})
export class AddToCartButtonComponent {
  @Input() bookId: number = 0;
  @Input() quantity: number = 1;
  loading: boolean = false;

  constructor(
    private cartService: CartService,
    private authService: AuthService
  ) {}

  addToCart() {
    if (!this.authService.isLoggedIn()) {
      alert('Please login to add items to cart');
      return;
    }

    this.loading = true;
    const userId = this.authService.getCurrentUserId();
    
    console.log('=== ADD TO CART DEBUG ===');
    console.log('Current User ID:', userId);
    console.log('Book ID:', this.bookId);
    console.log('Quantity:', this.quantity);
    console.log('User Role:', this.authService.getUserRole());
    console.log('========================');
    
    if (!userId) {
      console.error('No user ID found');
      alert('User session error. Please login again.');
      this.loading = false;
      return;
    }

    // First, try to get existing cart for user
    this.cartService.getCartByUserId(userId).subscribe({
      next: (cart) => {
        console.log('Found existing cart for user', userId, ':', cart);
        this.addItemToCart(cart.cartId);
      },
      error: (err) => {
        console.log('Error getting cart for user', userId, ':', err);
        if (err.status === 404) {
          console.log('Cart not found, creating new cart for user:', userId);
          this.createCartAndAddItem(userId);
        } else {
          console.error('Unexpected error:', err);
          this.handleError('Failed to access your cart. Please try again.');
        }
      }
    });
  }

  private addItemToCart(cartId: number) {
    console.log('Adding item to cart:', cartId, 'Book ID:', this.bookId);
    
    this.cartService.addCartItem({
      cartId: cartId,
      bookId: this.bookId,
      quantity: this.quantity
    }).subscribe({
      next: (cartItem) => {
        console.log('Successfully added item to cart:', cartItem);
        this.loading = false;
        alert('Item added to cart successfully!');
      },
      error: (err) => {
        console.error('Error adding item to cart:', err);
        this.handleError('Failed to add item to cart.');
      }
    });
  }

  private createCartAndAddItem(userId: number) {
    console.log('Creating new cart for user:', userId);
    
    this.cartService.createCart(userId).subscribe({
      next: (cart) => {
        console.log('Created new cart for user', userId, ':', cart);
        this.addItemToCart(cart.cartId);
      },
      error: (err) => {
        console.error('Error creating cart for user', userId, ':', err);
        this.handleError('Failed to create cart.');
      }
    });
  }

  private handleError(message: string = 'Failed to add item to cart. Please try again.') {
    this.loading = false;
    alert(message);
  }
}
