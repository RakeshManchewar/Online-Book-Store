import { Component, OnInit } from '@angular/core';
import { Book } from '../../book';
import { Router } from '@angular/router';
import { CartService } from '../../cart.service';
import { HttpClient } from '@angular/common/http';
import { AuthService } from '../../auth.service';
import { AddCartItemRequest } from '../../cart';
import { catchError, switchMap } from 'rxjs/operators';
import { throwError } from 'rxjs';
import { BooksService } from '../../books.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-store',
  standalone: false,
  templateUrl: './store.component.html',
  styleUrls: ['./store.component.css']
})
export class StoreComponent implements OnInit {
  books: Book[] = [];
  filteredBooks: Book[] = [];
  searchTerm: string = '';
  defaultImage = 'assets/coverimages/default.jpg';

  constructor(
    private booksService: BooksService,
    private router: Router,
    private cartService: CartService,
    private http: HttpClient,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this.loadBooks();
  }

  loadBooks(): void {
    this.booksService.getBooks().subscribe(
      (books: Book[]) => {
        this.books = books;
        this.filteredBooks = [...this.books];
      },
      (error) => {
        console.error('Error fetching books:', error);
      }
    );
  }

  search(): void {
    if (!this.searchTerm.trim()) {
      this.filteredBooks = [...this.books];
      return;
    }
    
    const term = this.searchTerm.toLowerCase();
    this.filteredBooks = this.books.filter(book => 
      book.bookTitle.toLowerCase().includes(term) || 
      book.bookAuthor?.toLowerCase().includes(term) ||
      book.description?.toLowerCase().includes(term)
    );
  }

  getImageUrl(bookId: number): string {
    return `assets/coverimages/${bookId}.jpg`;
  }

  handleImageError(event: any): void {
    event.target.src = this.defaultImage;
  }

  viewDetails(bookId: number): void {
    this.router.navigate(['/book-details', bookId]);
  }

  addToCart(book: Book): void {
    const userId = this.authService.getCurrentUserId();
    
    // Check for logged-in user first
    if (!userId || isNaN(userId)) {
      if (confirm('Please log in to add items to your cart. Go to login page?')) {
        this.router.navigate(['/login']);
      }
      return;
    }

    // Then check stock availability
    if (book.availableStock <= 0) {
      this.showError('This book is out of stock');
      return;
    }

    const loadingMsg = this.showLoading('Adding to cart...');

    this.cartService.getOrCreateCartForUser(userId).pipe(
      switchMap(cart => {
        const request: AddCartItemRequest = {
          cartId: cart.cartId,
          bookId: book.bookId,
          quantity: 1
        };
        return this.cartService.addCartItem(request);
      }),
      catchError(err => {
        this.showError('Failed to add item to cart');
        return throwError(() => err);
      })
    ).subscribe({
      next: () => {
        loadingMsg.close();
        //this.showSuccess(`${book.bookTitle} added to cart!`);
        Swal.fire({
                  title: 'Success',
                  text: 'Item Added to Cart',
                  //text: `${book.bookTitle} book added to cart!`,
                  icon: 'success'
                });
      },
      error: () => loadingMsg.close()
    });
  }

  private showLoading(message: string): any {
    console.log(message);
    return { close: () => {} };
  }

  private showSuccess(message: string): void {
    alert(message);
  }

  private showError(message: string): void {
    alert(message);
  }
}
