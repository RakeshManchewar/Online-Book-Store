import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Book } from '../book-shelf/book.model';
import { BookService } from '../book-shelf/book.service';
import { NavigationService } from '../../navigation.service';
import { AuthService } from '../../auth.service';


@Component({
  selector: 'app-book-detail',
  standalone: false,
  templateUrl: './book-detail.component.html',
  styleUrls: ['./book-detail.component.css']
})
export class BookDetailComponent implements OnInit {
  book: Book | undefined;
  userRole: string = 'guest';

  constructor(
    private route: ActivatedRoute,
    private bookService: BookService,
    private navigationService: NavigationService,
    private authService: AuthService
  ) { }

  ngOnInit(): void {
    this.getBook();
    this.userRole = this.authService.getUserRole();
  }

  getBook(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.bookService.getBook(id).subscribe(book => this.book = book);
  }

  addToCart(): void {
    if (this.book) {
      this.bookService.addToCart(this.book);
    }
  }

  goBack(): void {
    this.navigationService.navigateToBookShelf();
  }
}
