// book-shelf.component.ts
import { Component, OnInit } from '@angular/core';
import { Book } from './book.model';
import { BookService } from './book.service';
import { BooksService } from '../../books.service';

@Component({
  selector: 'app-book-shelf',
  standalone: false,
  templateUrl: './book-shelf.component.html',
  styleUrl: './book-shelf.component.css'
})

export class BookShelfComponent implements OnInit {
  books: Book[] = [];
  filteredBooks: Book[] = [];
  searchTerm: string = '';
  editableBook: Book | null = null;

  constructor(
    private bookService: BookService,
    private booksService: BooksService
  ) { }

  ngOnInit(): void {
    this.loadBooks();
  }

  loadBooks(): void {
    this.bookService.getBooks().subscribe(books => {
      this.books = books;
      this.filteredBooks = books;
    });
  }

  search(): void {
    if (!this.searchTerm.trim()) {
      this.filteredBooks = this.books;
      return;
    }
    
    const term = this.searchTerm.toLowerCase();
    
    this.filteredBooks = this.books.filter(book => 
      book.title.toLowerCase().includes(term) || 
      book.author.toLowerCase().includes(term) ||
      book.description.toLowerCase().includes(term)
    );
  }

  addToCart(book: Book): void {
    this.bookService.addToCart(book);
    // Optional: Add a toast notification or feedback for user
  }
}