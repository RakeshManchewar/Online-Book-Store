import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { Book } from './book.model';

@Injectable({
  providedIn: 'root'
})
export class BookService {
  private apiUrl = 'http://localhost:4200/api/books';
  private cartItems: Book[] = [];

  // Sample data for testing - remove when connecting to real API
  private mockBooks: Book[] = [
    {
      id: 1,
      title: 'Elites',
      author: 'F. Scott Fitzgerald',
      description: 'A classic novel of the Jazz Age',
      imageUrl: 'assets/Elite.jpg', 
      price: 12.99,
      originalPrice: 19.99,
      inStock: true
    },
    {
      id: 2,
      title: 'Singapore',
      author: 'Harper Lee',
      description: 'Classic of modern American literature',
      imageUrl: 'assets/Singapore.jpg',
      price: 11.50,
      originalPrice: 15.00,
      inStock: true
    },
    {
      id: 3,
      title: 'The Banking Cards',
      author: 'George Orwell',
      description: 'Dystopian social science fiction',
      imageUrl: 'assets/PetroDollar.jpg',
      price: 9.99,
      originalPrice: 14.99,
      inStock: true
    },
    {
      id: 4,
      title: 'The Rise & Fall of the Dollar',
      author: 'Jane Austen',
      description: 'Romantic novel of manners',
      imageUrl: 'assets/Dollar.jpg',
      price: 8.50,
      originalPrice: 12.99,
      inStock: true
    },
    {
      id: 5,
      title: 'Communism',
      author: 'Stalin',
      description: 'Lets Bring Back USSR to its full Glory',
      imageUrl: 'assets/Communism.jpg',
      price: 8.50,
      originalPrice: 12.99,
      inStock: true
    }
  ];

  constructor(private http: HttpClient) { }

  getBooks(): Observable<Book[]> {
    return of(this.mockBooks);
  }

  getBook(id: number): Observable<Book> {
    const book = this.mockBooks.find(b => b.id === id);
    return of(book as Book);
  }

  addToCart(book: Book): void {
    this.cartItems.push(book);
    console.log('Book added to cart:', book.title);
    console.log('Current cart:', this.cartItems);
  }

  getCartItems(): Book[] {
    return this.cartItems;
  }
}