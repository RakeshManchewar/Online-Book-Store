import { Component } from '@angular/core';
import { Book } from '../../book';
import { BooksService } from '../../books.service';

import Swal from 'sweetalert2';
import { error } from 'console'; 
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-add-book',
  templateUrl: './add-book.component.html',
  styleUrls: ['./add-book.component.css'],
  standalone: false
})

export class AddBookComponent {
  book: Book = {
    bookId: null as any,
    bookTitle: '',
    bookAuthor: '',
    price: null as any,
    description: '',
    availableStock: null as any
  }

  constructor (private bookService: BooksService) {}

  onSubmit(form: NgForm) {
  if (form.valid) 
    {
    this.bookService.saveBook(this.book).subscribe(
      () => 
      {
        Swal.fire('Book added successfully!', '', 'success');
        form.resetForm();
        this.book = { bookId: 0, bookTitle: '', bookAuthor: '', price: 0, description: '', availableStock: 0};
      },
      (error) => 
      {
        Swal.fire('Error adding Book! ', error.error.message, 'error');
      }
    );
    } else {
  Swal.fire('Error!', 'Please fill in all required fiels.', 'error');
    }
  }
}
