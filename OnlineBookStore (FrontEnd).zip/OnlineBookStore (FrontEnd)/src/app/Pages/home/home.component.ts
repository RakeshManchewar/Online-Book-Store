import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  standalone: false,
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {

  featuredBooks = [
    {
      title: 'The Ming Dynasty',
      author: 'Maria Reynolds',
      price: 19.99,
      coverUrl: 'assets/Ming.jpg'
    },
    {
      title: 'The Mongol Dynasty',
      author: 'James Parker',
      price: 24.99,
      coverUrl: 'assets/Mongol.jpg'
    },
    {
      title: 'Hedge Funds',
      author: 'Sarah Chen',
      price: 21.50,
      coverUrl: 'assets/BlackRock.jpg'
    },
    {
      title: 'XAUUSD',
      author: 'Alex Morgan',
      price: 18.75,
      coverUrl: 'assets/Gold.jpg'
    }
  ];

  categories = [
    'Fantasy', 'Science Fiction', 'Mystery', 'Romance',
    'Biography', 'History', 'Self-Help', 'Children\'s'
  ];

  features = [
    {
      icon: '📚',
      title: 'Vast Selection',
      description: 'Discover millions of titles across every genre imaginable, from bestsellers to rare finds.'
    },
    {
      icon: '🚚',
      title: 'Fast Delivery',
      description: 'Get your books delivered to your doorstep with our express shipping options.'
    },
    {
      icon: '💰',
      title: 'Great Value',
      description: 'Enjoy competitive prices, regular discounts, and exclusive member deals.'
    }
  ];

  testimonials = [
    {
      text: 'Everything we hear is an opinion, not a fact. Everything we see is a perspective, not the truth.',
      author: 'Marcus Aurelius',
      title: 'Avid Reader'
    },
    {
      text: 'The Jack of all Trades is Master of None, But He is often times better than the Master of one',
      author: 'David W.',
      title: 'Book Collector'
    },
    {
      text: 'You get what you fight for, not what you wish for.',
      author: 'Michelle K.',
      title: 'Elementary Teacher'
    }
  ];

  constructor() {}

  subscribeToNewsletter(email: string): void {
    console.log('Subscribing email:', email);
  }

  handleImageError(event: any): void {
    event.target.src = 'assets/book-cover-placeholder.jpg';
  }
}