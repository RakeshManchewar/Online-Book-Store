import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { Book } from '../../book';
import { BooksService } from '../../books.service';
import { CartService } from '../../cart.service';
import { NavigationService } from '../../navigation.service';
import { AuthService } from '../../auth.service';
import { AddCartItemRequest } from '../../cart';
import { catchError, switchMap, throwError } from 'rxjs';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-book-details',
  standalone: false,
  templateUrl: './book-details.component.html',
  styleUrls: ['./book-details.component.css']
})
export class BookDetailsComponent implements OnInit {
  book: Book | undefined;
  backButtonText: string = 'Store';
  userRole: string = 'guest';
  defaultImage = 'assets/coverimages/default.jpg';

  constructor(
    private route: ActivatedRoute,
    private booksService: BooksService,
    private location: Location,
    private cartService: CartService,
    private navigationService: NavigationService,
    private authService: AuthService
  ) {}
  
  ngOnInit(): void {
    this.getBook();
    this.userRole = this.authService.getUserRole();
  }

  getBook(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.booksService.getBook(id).subscribe(
      book => {
        this.book = book;
      },
      error => {
        console.error('Error fetching book:', error);
      }
    );
  }

  getImageUrl(bookId: number): string {
    return `assets/coverimages/${bookId}.jpg`;
  }

  handleImageError(event: any): void {
    event.target.src = this.defaultImage;
  }

  addToCart(book: Book): void {
  if (book.availableStock <= 0) {
    this.showError('This book is out of stock');
    return;
  }

  const userId = this.authService.getCurrentUserId();
    if (!userId || isNaN(userId)) {
      this.showError('Please log in to add items to your cart');
      return;
    }

    const loadingMsg = this.showLoading('Adding to cart...');

    this.cartService.getOrCreateCartForUser(userId).pipe(
      switchMap(cart => {
        const request: AddCartItemRequest = {
          cartId: cart.cartId,
          bookId: book.bookId,
          quantity: 1
        };
        return this.cartService.addCartItem(request);
      }),
      catchError(err => {
        this.showError('Failed to add item to cart');
        return throwError(() => err);
      })
    ).subscribe({
      next: () => {
        loadingMsg.close();
        //this.showSuccess(`${book.bookTitle} added to cart!`);
        Swal.fire({
                          title: 'Success',
                          text: 'Item Added to Cart',
                          //text: `${book.bookTitle} book added to cart!`,
                          icon: 'success'
                        });
      },
      error: () => loadingMsg.close()
    });
  }

  private showLoading(message: string): any {
    // Implement your loading indicator
    console.log(message); // Replace with actual loading UI
    return { close: () => {} };
  }

  private showSuccess(message: string): void {
    alert(message); // Replace with toast/snackbar
  }

  private showError(message: string): void {
    alert(message); // Replace with error dialog
  }

  goBack(): void {
    this.location.back();
  }
}
