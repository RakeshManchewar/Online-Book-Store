import { Component } from '@angular/core';

@Component({
  selector: 'app-ordered',
  standalone: false,
  templateUrl: './ordered.component.html',
  styleUrl: './ordered.component.css'
})
export class OrderedComponent {

}
