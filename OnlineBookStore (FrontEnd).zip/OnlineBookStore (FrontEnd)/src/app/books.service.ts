import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Book } from './book';

@Injectable({
  providedIn: 'root'
})
export class BooksService {
  private api = 'http://localhost:8080';
  
  constructor(private http: HttpClient) { }

  saveBook(bookData: Book): Observable<Book> {
    return this.http.post<Book>(`${this.api}/api/books/save/book`, bookData); 
  }

  getBooks(): Observable<Book[]> {
    return this.http.get<Book[]>(`${this.api}/api/books/get/book`);
  }

  getBook(bookId: number): Observable<Book> {
    return this.http.get<Book>(`${this.api}/api/books/${bookId}`);
  }

  deleteBook(bookId: number): Observable<void> {
    return this.http.delete<void>(`${this.api}/api/books/delete/book/${bookId}`);
  }

  updateBook(bookId: number, bookData: Book): Observable<Book> {
    return this.http.put<Book>(`${this.api}/api/books/update/book/${bookId}`, bookData);
  }
}
