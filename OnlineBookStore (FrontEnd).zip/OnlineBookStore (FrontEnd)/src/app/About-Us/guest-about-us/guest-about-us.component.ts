import { Component } from '@angular/core';

@Component({
  selector: 'app-guest-about-us',
  standalone: false,
  templateUrl: './guest-about-us.component.html',
  styleUrl: './guest-about-us.component.css'
})
export class GuestAboutUsComponent {

}
