import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GuestAboutUsComponent } from './guest-about-us.component';

describe('GuestAboutUsComponent', () => {
  let component: GuestAboutUsComponent;
  let fixture: ComponentFixture<GuestAboutUsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [GuestAboutUsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GuestAboutUsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
