import { Component } from '@angular/core';

@Component({
  selector: 'app-user-about-us',
  standalone: false,
  templateUrl: './user-about-us.component.html',
  styleUrl: './user-about-us.component.css'
})
export class UserAboutUsComponent {

}
