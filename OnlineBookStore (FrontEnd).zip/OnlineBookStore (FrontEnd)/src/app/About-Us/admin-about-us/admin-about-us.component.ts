import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-about-us',
  standalone: false,
  templateUrl: './admin-about-us.component.html',
  styleUrl: './admin-about-us.component.css'
})
export class AdminAboutUsComponent {

}
