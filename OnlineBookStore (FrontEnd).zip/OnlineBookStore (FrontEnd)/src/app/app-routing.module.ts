import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BookDetailComponent } from './Pages/book-detail/book-detail.component';
import { BookDetailsComponent } from './Pages/book-details/book-details.component';

import { BookShelfComponent } from './Pages/book-shelf/book-shelf.component';
import { AboutUsComponent } from './Pages/about-us/about-us.component';

import { CartComponent } from './Pages/cart/cart.component';
import { OrderedComponent } from './Pages/ordered/ordered.component';

import { LibraryComponent } from './Pages/library/library.component';
import { AddBookComponent } from './Pages/add-book/add-book.component';
import { UsersComponent } from './Pages/users/users.component';

import { LogInComponent } from './Authentication/log-in/log-in.component';
import { RegisterComponent } from './Authentication/register/register.component';

import { GuestHomeComponent } from './Home/guest-home/guest-home.component';
import { AdminHomeComponent } from './Home/admin-home/admin-home.component';
import { UserHomeComponent } from './Home/user-home/user-home.component';

import { GuestAboutUsComponent } from './About-Us/guest-about-us/guest-about-us.component';
import { AdminAboutUsComponent } from './About-Us/admin-about-us/admin-about-us.component';
import { UserAboutUsComponent } from './About-Us/user-about-us/user-about-us.component';

import { GuestBookShelfComponent } from './Book-Shelf/guest-book-shelf/guest-book-shelf.component';
import { AdminBookShelfComponent } from './Book-Shelf/admin-book-shelf/admin-book-shelf.component';
import { UserBookShelfComponent } from './Book-Shelf/user-book-shelf/user-book-shelf.component';

import { AdminStoreComponent } from './Store/admin-store/admin-store.component';
import { UserStoreComponent } from './Store/user-store/user-store.component';

import { AdminCartComponent } from './Cart/admin-cart/admin-cart.component';
import { UserCartComponent } from './Cart/user-cart/user-cart.component';

const routes: Routes = [
  { path: '', redirectTo: '/guest-dashboard', pathMatch: 'full' },

  { path: '', component: GuestHomeComponent},

  { path: 'Book-Shelf', component: BookShelfComponent },
  { path: 'book/:id', component: BookDetailComponent },
  { path: 'About-Us', component: AboutUsComponent },

  { path: 'LogIn', component: LogInComponent },
  { path: 'Register', component: RegisterComponent },

  { path: 'Cart', component: CartComponent },
  { path: 'Ordered', component: OrderedComponent},

  { path: 'AddBook', component: AddBookComponent },
  { path: 'Library', component: LibraryComponent },
  { path: 'Users', component: UsersComponent},

  { path: 'guest-dashboard', component: GuestHomeComponent},
  { path: 'admin-dashboard', component: AdminHomeComponent},
  { path: 'user-dashboard', component: UserHomeComponent},

  { path: 'Guest-About-Us', component: GuestAboutUsComponent},
  { path: 'Admin-About-Us', component: AdminAboutUsComponent},
  { path: 'User-About-Us', component: UserAboutUsComponent},

  { path: 'Guest-Book-Shelf', component: GuestBookShelfComponent},
  { path: 'Admin-Book-Shelf', component: AdminBookShelfComponent},
  { path: 'User-Book-Shelf', component: UserBookShelfComponent},

  { path: 'Admin-Store', component: AdminStoreComponent},
  { path: 'User-Store', component: UserStoreComponent},

  { path: 'Admin-Cart', component: AdminCartComponent},
  { path: 'User-Cart', component: UserCartComponent},

  { path: 'book-details/:id', component: BookDetailsComponent, data: { source: 'store' } },
  { path: 'book-details/:id', component: BookDetailsComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
