export interface Book {
  bookId: number;
  bookTitle: string;
  bookAuthor: string;
  price: number;
  description: string;
  availableStock: number;
}