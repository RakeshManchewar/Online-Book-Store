import { NgModule } from '@angular/core';
import { BrowserModule, provideClientHydration, withEventReplay } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BookDetailComponent } from './Pages/book-detail/book-detail.component';
import { BookDetailsComponent } from './Pages/book-details/book-details.component';
import { AddToCartButtonComponent } from './Pages/add-to-cart-button/add-to-cart-button.component';

import { FooterComponent } from './Pages/footer/footer.component';

import { HomeComponent } from './Pages/home/home.component';
import { BookShelfComponent } from './Pages/book-shelf/book-shelf.component';
import { StoreComponent } from './Pages/store/store.component';
import { AboutUsComponent } from './Pages/about-us/about-us.component';

import { CartComponent } from './Pages/cart/cart.component';
import { OrderedComponent } from './Pages/ordered/ordered.component';

import { LibraryComponent } from './Pages/library/library.component';
import { AddBookComponent } from './Pages/add-book/add-book.component';
import { UsersComponent } from './Pages/users/users.component';

import { LogInComponent } from './Authentication/log-in/log-in.component';
import { RegisterComponent } from './Authentication/register/register.component';

import { GuestHeaderComponent } from './Headers/guest-header/guest-header.component';
import { AdminHeaderComponent } from './Headers/admin-header/admin-header.component';
import { UserHeaderComponent } from './Headers/user-header/user-header.component';

import { GuestHomeComponent } from './Home/guest-home/guest-home.component';
import { AdminHomeComponent } from './Home/admin-home/admin-home.component';
import { UserHomeComponent } from './Home/user-home/user-home.component';

import { GuestBookShelfComponent } from './Book-Shelf/guest-book-shelf/guest-book-shelf.component';
import { AdminBookShelfComponent } from './Book-Shelf/admin-book-shelf/admin-book-shelf.component';
import { UserBookShelfComponent } from './Book-Shelf/user-book-shelf/user-book-shelf.component';

import { AdminStoreComponent } from './Store/admin-store/admin-store.component';
import { UserStoreComponent } from './Store/user-store/user-store.component';

import { GuestAboutUsComponent } from './About-Us/guest-about-us/guest-about-us.component';
import { AdminAboutUsComponent } from './About-Us/admin-about-us/admin-about-us.component';
import { UserAboutUsComponent } from './About-Us/user-about-us/user-about-us.component';

import { AdminCartComponent } from './Cart/admin-cart/admin-cart.component';
import { UserCartComponent } from './Cart/user-cart/user-cart.component';

@NgModule({
  declarations: [
    AppComponent,
    FooterComponent,
    HomeComponent,
    AboutUsComponent,
    LogInComponent,
    RegisterComponent,
    CartComponent,
    BookShelfComponent,
    BookDetailComponent,
    AddBookComponent,
    LibraryComponent,
    UserHeaderComponent,
    AdminHeaderComponent,
    GuestHeaderComponent,
    AdminHomeComponent,
    UserHomeComponent,
    GuestHomeComponent,
    OrderedComponent,
    UsersComponent,
    GuestAboutUsComponent,
    AdminAboutUsComponent,
    UserAboutUsComponent,
    GuestBookShelfComponent,
    AdminBookShelfComponent,
    UserBookShelfComponent,
    AddToCartButtonComponent,
    StoreComponent,
    AdminStoreComponent,
    UserStoreComponent,
    BookDetailsComponent,
    AdminCartComponent,
    UserCartComponent,
  ],

  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    CommonModule
  ],

  exports: [
    AdminHeaderComponent,
    UserHeaderComponent,
    GuestHeaderComponent
  ],

  providers: [
    provideClientHydration(withEventReplay())
  ],

  bootstrap: [AppComponent]
})

export class AppModule {}