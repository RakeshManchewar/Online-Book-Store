import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-guest-home',
  standalone: false,
  templateUrl: './guest-home.component.html',
  styleUrl: './guest-home.component.css'
})

export class GuestHomeComponent {

}
