export interface Cart {
  cartId: number;
  user: User;
}

export interface CartItem {
  cartItemId: number;
  cart: Cart;
  book: Book;
  quantity: number;
}

export interface User {
  userId: number;
  userName: string;
  userEmail: string;
  userPassword: string;
  role: Role[];
}

export interface Book {
  bookId: number;
  bookTitle: string;
  bookAuthor: string;
  price: number;
  description: string;
  availableStock: number;
}

export interface Role {
  roleName: string;
}

export interface AddCartItemRequest {
  cartId: number;
  bookId: number;
  quantity: number;
}

export interface UpdateQuantity {
  cartItemId: number;
  quantity: number;
}