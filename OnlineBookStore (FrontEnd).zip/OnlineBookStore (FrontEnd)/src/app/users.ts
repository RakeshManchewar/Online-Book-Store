export interface User {
  userId: number;
  userName: string;
  userEmail: string;
  userPassword: string;
  role?: Set<Role>;
}

export interface Role {
  roleName: string;
}