import { Component } from '@angular/core';

@Component({
  selector: 'app-guest-header',
  standalone: false,
  templateUrl: './guest-header.component.html',
  styleUrl: './guest-header.component.css'
})
export class GuestHeaderComponent {}
