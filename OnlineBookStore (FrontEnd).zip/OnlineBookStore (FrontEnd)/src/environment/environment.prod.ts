export const environment = {
  production: true,
  apiUrl: 'https://your-production-url/api' // Your production backend URL
};